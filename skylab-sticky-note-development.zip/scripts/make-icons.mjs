import zlib from 'zlib';
import fs from 'fs';
const crcT = new Uint32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
const crc = (b) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
function png(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 4 + 1)] = 0; rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const rr = (x, y, x0, y0, x1, y1, r) => { const cx = Math.min(Math.max(x, x0 + r), x1 - r), cy = Math.min(Math.max(y, y0 + r), y1 - r); return (x - cx) ** 2 + (y - cy) ** 2 <= r * r && x >= x0 && x <= x1 && y >= y0 && y <= y1; };
function sample(x, y) {
  if (!rr(x, y, 0.08, 0.08, 0.92, 0.92, 0.2)) return null;
  if (x > 0.64 && y < 0.36 && x - 0.64 > y - 0.08) return null; // cut corner
  if (x > 0.64 && y < 0.36 && x - 0.64 <= y - 0.08) return [232, 168, 0, 255]; // fold
  const bars = [[0.52, 0.76], [0.65, 0.76], [0.78, 0.56]];
  for (const [by, bx] of bars) if (rr(x, y, 0.24, by - 0.025, bx, by + 0.025, 0.025)) return [31, 35, 40, 215];
  const t = (x + y) / 2; return [Math.round(255 - 3 * t), Math.round(230 - 36 * t), Math.round(110 - 80 * t), 255];
}
for (const s of [16, 32, 48, 128]) {
  const buf = Buffer.alloc(s * s * 4); const SS = 4;
  for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
    let r = 0, g = 0, b = 0, a = 0;
    for (let j = 0; j < SS; j++) for (let i = 0; i < SS; i++) { const c = sample((x + (i + .5) / SS) / s, (y + (j + .5) / SS) / s); if (c) { r += c[0] * c[3]; g += c[1] * c[3]; b += c[2] * c[3]; a += c[3]; } }
    const o = (y * s + x) * 4; const n = SS * SS;
    if (a) { buf[o] = r / a; buf[o + 1] = g / a; buf[o + 2] = b / a; buf[o + 3] = a / n; }
  }
  fs.writeFileSync(`public/extension/icons/icon${s}.png`, png(s, s, buf));
}
console.log('icons ok');
