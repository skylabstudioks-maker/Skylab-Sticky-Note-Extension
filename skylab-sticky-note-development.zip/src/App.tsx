import { useEffect, useMemo, useRef, useState } from "react";

const ZIP = "./skylab-sticky-note-extension.zip";
const DASH = "./extension/notes.html";
const VERSION = "1.0.0";

const COLORS = [
  { name: "Yellow", hex: "#FFE066" },
  { name: "Blue", hex: "#74C0FC" },
  { name: "Red", hex: "#FF8787" },
  { name: "Green", hex: "#8CE99A" },
  { name: "Black", hex: "#212529" },
  { name: "White", hex: "#FFFFFF" },
];

function ink(hex: string) {
  const n = parseInt(hex.slice(1), 16);
  const l = (0.2126 * (n >> 16) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
  return l > 0.5 ? "#1f2328" : "#ffffff";
}
function rgb(hex: string) {
  const n = parseInt(hex.slice(1), 16);
  return `${n >> 16}, ${(n >> 8) & 255}, ${n & 255}`;
}
const timeNow = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true });

/* ------------------------------------------------------------ live demo note */
function DemoNote() {
  const [color, setColor] = useState(COLORS[0].hex);
  const [hideTools, setHideTools] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [title, setTitle] = useState("Ship landing page");
  const [edited, setEdited] = useState(timeNow());
  const [checks, setChecks] = useState([true, false, false]);
  const [bold, setBold] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number } | null>(null);
  const edRef = useRef<HTMLDivElement>(null);
  const fg = ink(color);
  const labels = ["Write copy", "Record demo GIF", "Publish to the stores"];

  const touch = () => setEdited(timeNow());
  return (
    <div
      className="relative mx-auto w-full max-w-[360px] select-none"
      style={{ transform: `translate(${pos.x}px, ${pos.y}px)`, ["--n" as string]: color }}
    >
      <div className="overflow-hidden rounded-2xl shadow-2xl ring-1 ring-black/10" style={{ background: `rgba(${rgb(color)}, .5)`, backdropFilter: "blur(8px)" }}>
        <div
          className="flex cursor-grab items-center gap-1 px-3 py-2 active:cursor-grabbing"
          style={{ background: color, color: fg }}
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest("button,input")) return;
            drag.current = { sx: e.clientX, sy: e.clientY, ox: pos.x, oy: pos.y };
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => drag.current && setPos({ x: drag.current.ox + e.clientX - drag.current.sx, y: drag.current.oy + e.clientY - drag.current.sy })}
          onPointerUp={() => (drag.current = null)}
        >
          <input
            value={title}
            onChange={(e) => { setTitle(e.target.value); touch(); }}
            aria-label="Note title"
            className="min-w-0 flex-1 rounded bg-transparent px-1 text-[15px] font-semibold outline-none focus:bg-black/10"
          />
          <button onClick={() => setHideTools((v) => !v)} title="Hide / show toolbar" className="grid h-7 w-7 place-items-center rounded-lg hover:bg-black/15">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: hideTools ? "rotate(180deg)" : "none", transition: "transform .2s" }}><polyline points="6 9 12 15 18 9" /></svg>
          </button>
          <button onClick={() => setPinned((v) => !v)} title="Pin" className={`grid h-7 w-7 place-items-center rounded-lg hover:bg-black/15 ${pinned ? "bg-black/20" : ""}`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill={pinned ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 17v5M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z" /></svg>
          </button>
        </div>
        {!hideTools && (
          <div className="flex items-center gap-2 px-3 pb-2 text-[11.5px]" style={{ background: color, color: fg }}>
            <span className="truncate rounded-full bg-black/10 px-2 py-0.5">🔗 example.com/launch</span>
            <span className="flex-1" />
            <span className="rounded-full border border-current/40 px-2 py-0.5">🏷 work</span>
            <span className="whitespace-nowrap opacity-75">Edited at {edited}</span>
          </div>
        )}
        <div className="px-4 py-3 text-[14px] leading-relaxed" style={{ color: fg }}>
          <div
            ref={edRef}
            contentEditable
            suppressContentEditableWarning
            onInput={touch}
            className="mb-2 min-h-[56px] outline-none"
            style={{ fontWeight: bold ? 700 : 400 }}
          >
            Launch checklist for the extension. Click here and type — it auto-saves.
          </div>
          {labels.map((l, i) => (
            <label key={l} className="flex cursor-pointer items-center gap-2">
              <input type="checkbox" checked={checks[i]} onChange={() => { setChecks((c) => c.map((v, j) => (j === i ? !v : v))); touch(); }} className="h-4 w-4 accent-green-600" />
              <span style={{ textDecoration: checks[i] ? "line-through" : "none", opacity: checks[i] ? 0.6 : 1 }}>{l}</span>
            </label>
          ))}
        </div>
        {!hideTools && (
          <div className="flex items-center gap-1 overflow-x-auto px-2 py-1.5" style={{ background: color, color: fg }}>
            <button onClick={() => setBold((b) => !b)} className={`h-7 min-w-7 rounded-lg px-2 text-sm font-bold hover:bg-black/15 ${bold ? "bg-black/25" : ""}`} title="Bold">B</button>
            {["I", "U", "S"].map((t) => (<span key={t} className="grid h-7 min-w-7 place-items-center rounded-lg px-2 text-sm opacity-70">{t}</span>))}
            <span className="mx-1 h-4 w-px bg-current opacity-25" />
            {["☑", "✎", "🖼", "▦", "⏰"].map((t) => (<span key={t} className="grid h-7 min-w-7 place-items-center rounded-lg px-1.5 text-sm opacity-80">{t}</span>))}
          </div>
        )}
      </div>
      <div className="mt-4 flex items-center justify-center gap-2" role="radiogroup" aria-label="Note color">
        {COLORS.map((c) => (
          <button key={c.hex} role="radio" aria-checked={color === c.hex} title={c.name} onClick={() => { setColor(c.hex); touch(); }}
            className={`h-7 w-7 rounded-full border-2 transition hover:scale-110 ${color === c.hex ? "border-slate-900 ring-2 ring-white ring-offset-2 ring-offset-slate-900" : "border-black/20"}`} style={{ background: c.hex }} />
        ))}
        <label title="Color wheel" className="relative h-7 w-7 cursor-pointer overflow-hidden rounded-full border-2 border-black/20" style={{ background: "conic-gradient(red,yellow,lime,aqua,blue,magenta,red)" }}>
          <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="absolute -inset-2 h-12 w-12 cursor-pointer opacity-0" />
        </label>
      </div>
      <p className="mt-2 text-center text-xs text-slate-400">Live demo — drag the header, edit, tick, recolor.</p>
    </div>
  );
}

/* ------------------------------------------------------------------- content */
const FEATURES = [
  ["📌", "Website-specific notes", "Every note remembers the exact page URL and title. Bind it to one page, a whole site, or every site — it appears automatically when you return."],
  ["🪟", "Floating, draggable overlay", "Move notes anywhere and resize from all eight edges and corners, like a crop box. Notes float above the page in a Shadow DOM so site styles never leak in."],
  ["🎨", "Color-aware design", "Yellow, Blue, Red, Green, Black, White or any shade from the color wheel — plus a separate text color. Header and footer are solid; the writing area is 50% translucent."],
  ["🧰", "Single-row rich toolbar", "Fonts, size, H1, H2, bold, italic, underline, strikethrough and clear-formatting live in one tidy footer row. Hide it any time with the collapse icon before the pin."],
  ["✅", "Checklists, tables & images", "Tick boxes, dynamic tables with +/− rows & columns, and resizable, croppable image attachments — paste or drop pictures straight in."],
  ["✏️", "Drawing boards", "Sketch with pen and eraser on a resizable canvas, crop it, undo mistakes, and drop the drawing into your note as an image."],
  ["⏰", "Reminders that repeat", "Pop-up and system notifications at the time you pick. Repeat daily, weekdays, weekly, monthly or yearly, or snooze for 10 minutes."],
  ["🔒", "AES-256 locked notes", "Protect sensitive notes with a password. Encryption happens on your device with PBKDF2 + AES-GCM. Lose the password and the note is gone — and we warn you first."],
  ["🖱️", "Right-click to note", "Select any text on a page, right-click, and send it to a new sticky note in one move. Keyboard shortcuts for new note and show/hide too."],
  ["🗂️", "All Notes dashboard", "A full-page workspace with search, labels, website groups, pinning, archive, version history, duplicate, bulk actions and global find & replace."],
  ["📤", "Import & export anywhere", "Back up or move notes as .json (with CSS), .md, .doc, .sheet or .notepad — and import them back in bulk by drag & drop."],
  ["📴", "Local-first & offline", "No servers, no accounts, no tracking. Notes autosave to browser storage, work offline, and can optionally mirror into a folder you choose."],
] as const;

const LOGS = [
  { v: "1.0.0", d: "Initial release", items: ["Floating website notes with URL/title capture and smart per-page detection", "Single-row rich text footer, collapsible toolbar, color & text color wheels", "Checklists, tables, images, drawing boards with crop, reminders with recurrence", "AES-256-GCM locked notes, version history, find & replace, labels, archive", "All Notes dashboard with import/export (.json .md .doc .sheet .notepad)", "Right-click text-to-note, keyboard shortcuts, optional local folder mirror"] },
];

const FAQ = [
  ["Where are my notes stored?", "Only in your browser’s extension storage on this device (chrome.storage.local). Nothing is uploaded. Optionally you can also mirror notes as Markdown files into a folder you pick."],
  ["Does it work offline?", "Yes. There is no backend at all — everything is local, instant and auto-saved."],
  ["I forgot a note’s password. Can you recover it?", "No. Passwords are never stored and the key is derived from them, so a lost password means the note cannot be decrypted. Export or remove locks while you still remember it."],
  ["Which browsers are supported?", "Google Chrome, Microsoft Edge, Brave, Opera, Vivaldi, Arc and other Chromium browsers that support Manifest V3 (version 105+)."],
  ["Why can’t I add notes on some pages?", "Browsers block extensions on internal pages (chrome://, the web store, PDF viewer). Use the dashboard to write notes there."],
];

function Section({ id, eyebrow, title, children }: { id: string; eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="scroll-mt-20 px-5 py-20">
      <div className="mx-auto max-w-6xl">
        <p className="text-center text-sm font-bold uppercase tracking-widest text-amber-600">{eyebrow}</p>
        <h2 className="mx-auto mt-2 max-w-2xl text-center text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">{title}</h2>
        <div className="mt-12">{children}</div>
      </div>
    </section>
  );
}

function DownloadButton({ className = "" }: { className?: string }) {
  return (
    <a href={ZIP} download="skylab-sticky-note-extension.zip" className={`inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-yellow-300 to-amber-400 px-6 py-3.5 text-base font-bold text-slate-900 shadow-lg shadow-amber-500/30 transition hover:-translate-y-0.5 hover:shadow-xl active:scale-95 ${className}`}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" x2="12" y1="15" y2="3" /></svg>
      Download v{VERSION} (.zip)
    </a>
  );
}

export default function App() {
  const [menu, setMenu] = useState(false);
  const [browser, setBrowser] = useState<"chrome" | "edge">("chrome");
  const [faq, setFaq] = useState<number | null>(0);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    document.title = "Skylab Sticky Note – website-specific sticky notes for Chrome & Edge";
    const on = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", on); on();
    return () => window.removeEventListener("scroll", on);
  }, []);
  const steps = useMemo(() => {
    const url = browser === "chrome" ? "chrome://extensions" : "edge://extensions";
    return [
      ["Download & unzip", "Download the .zip above and extract it to a folder you will keep (for example Documents/skylab-sticky-note)."],
      [`Open ${url}`, `Paste ${url} into the address bar${browser === "edge" ? " (or Menu → Extensions → Manage extensions)" : ""}.`],
      ["Enable Developer mode", browser === "chrome" ? "Switch on “Developer mode” in the top-right corner." : "Switch on “Developer mode” in the left sidebar."],
      ["Load unpacked", "Click “Load unpacked” and select the extracted folder — the one that contains manifest.json."],
      ["Pin & start", "Pin the Skylab icon to your toolbar, open any website and click New note (or press Alt+Shift+N)."],
    ];
  }, [browser]);

  const nav = [["features", "Features"], ["dashboard", "Dashboard"], ["install", "Install"], ["security", "Security"], ["changelog", "Changelog"], ["faq", "FAQ"]];

  return (
    <div className="min-h-screen bg-white font-sans text-slate-700 antialiased">
      {/* nav */}
      <header className={`sticky top-0 z-40 border-b transition ${scrolled ? "border-slate-200 bg-white/90 backdrop-blur" : "border-transparent bg-white/60 backdrop-blur"}`}>
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <a href="#top" className="flex items-center gap-2.5 font-extrabold text-slate-900">
            <img src="./extension/icons/icon48.png" alt="" className="h-8 w-8 rounded-lg shadow" />
            Skylab Sticky Note
          </a>
          <nav className="hidden items-center gap-1 md:flex">
            {nav.map(([id, l]) => (<a key={id} href={`#${id}`} className="rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900">{l}</a>))}
            <a href={ZIP} download className="ml-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-bold text-white transition hover:bg-slate-700">Download</a>
          </nav>
          <button className="grid h-10 w-10 place-items-center rounded-lg hover:bg-slate-100 md:hidden" aria-label="Menu" aria-expanded={menu} onClick={() => setMenu((m) => !m)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d={menu ? "M18 6 6 18M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} /></svg>
          </button>
        </div>
        {menu && (
          <div className="border-t border-slate-200 bg-white px-5 py-3 md:hidden">
            {nav.map(([id, l]) => (<a key={id} href={`#${id}`} onClick={() => setMenu(false)} className="block rounded-lg px-3 py-2.5 font-semibold text-slate-700 hover:bg-slate-100">{l}</a>))}
            <a href={ZIP} download className="mt-2 block rounded-lg bg-slate-900 px-3 py-2.5 text-center font-bold text-white">Download</a>
          </div>
        )}
      </header>

      {/* hero */}
      <section id="top" className="relative overflow-hidden bg-gradient-to-b from-amber-50 via-white to-white px-5 pb-24 pt-16 sm:pt-24">
        <div className="pointer-events-none absolute -top-24 left-1/2 h-[480px] w-[900px] -translate-x-1/2 rounded-full bg-yellow-200/50 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-amber-800">
              <span className="h-2 w-2 animate-pulse rounded-full bg-amber-500" /> Chrome · Edge · Chromium · Manifest V3
            </span>
            <h1 className="mt-5 text-4xl font-black leading-[1.05] tracking-tight text-slate-900 sm:text-6xl">
              Sticky notes that <span className="bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">live on the websites</span> they belong to.
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-600">
              Skylab Sticky Note is your intelligent website-specific sticky note and annotation companion. Pin rich, colorful, optionally encrypted notes to any page — private, offline and free of servers.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <DownloadButton />
              <a href={DASH} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3.5 font-bold text-slate-800 transition hover:border-slate-400 hover:bg-slate-50 active:scale-95">Try the live dashboard →</a>
            </div>
            <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium text-slate-500">
              <span>✓ 100% local-first</span><span>✓ Works offline</span><span>✓ No account</span><span>✓ AES-256 locks</span>
            </div>
            <div className="mt-6 flex flex-wrap gap-3 text-sm">
              <span className="rounded-lg border border-dashed border-slate-300 px-3 py-2 text-slate-500">Chrome Web Store — coming soon</span>
              <span className="rounded-lg border border-dashed border-slate-300 px-3 py-2 text-slate-500">Microsoft Edge Add-ons — coming soon</span>
            </div>
          </div>
          <div className="relative rounded-3xl bg-gradient-to-br from-slate-800 to-slate-900 p-6 pb-8 shadow-2xl">
            <div className="mb-5 flex items-center gap-2"><i className="h-3 w-3 rounded-full bg-red-400" /><i className="h-3 w-3 rounded-full bg-yellow-400" /><i className="h-3 w-3 rounded-full bg-green-400" />
              <span className="ml-3 flex-1 truncate rounded-md bg-slate-700 px-3 py-1 text-xs text-slate-300">https://example.com/launch</span></div>
            <div className="space-y-3 pb-4 opacity-40"><div className="h-4 w-2/3 rounded bg-slate-500" /><div className="h-3 w-full rounded bg-slate-600" /><div className="h-3 w-5/6 rounded bg-slate-600" /><div className="h-3 w-3/4 rounded bg-slate-600" /></div>
            <div className="-mt-2"><DemoNote /></div>
          </div>
        </div>
      </section>

      {/* features */}
      <Section id="features" eyebrow="Everything you need" title="A complete note-taking toolkit, right on the page">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(([ic, t, d]) => (
            <article key={t} className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-amber-300 hover:shadow-lg">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-100 text-2xl transition group-hover:scale-110 group-hover:bg-amber-200">{ic}</div>
              <h3 className="mt-4 text-lg font-bold text-slate-900">{t}</h3>
              <p className="mt-1.5 text-[15px] leading-relaxed text-slate-600">{d}</p>
            </article>
          ))}
        </div>
      </Section>

      {/* dashboard */}
      <section id="dashboard" className="scroll-mt-20 bg-slate-900 px-5 py-20 text-slate-300">
        <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-amber-400">All Notes dashboard</p>
            <h2 className="mt-2 text-3xl font-extrabold text-white sm:text-4xl">Your whole workspace in one tab</h2>
            <ul className="mt-6 space-y-3">
              {["Search by text, label, title or URL; group by website", "Pin, archive (never delete), duplicate with “Make a copy”", "Version history & restore for every note", "Global find & replace across all notes", "Bulk select, export & import: .json .md .doc .sheet .notepad", "Reminders view, locked notes view, dark mode"].map((t) => (
                <li key={t} className="flex gap-3"><span className="mt-0.5 grid h-5 w-5 flex-none place-items-center rounded-full bg-amber-400 text-xs font-black text-slate-900">✓</span>{t}</li>
              ))}
            </ul>
            <a href={DASH} target="_blank" rel="noreferrer" className="mt-8 inline-flex rounded-xl bg-white px-6 py-3 font-bold text-slate-900 transition hover:bg-amber-100 active:scale-95">Open the dashboard demo</a>
            <p className="mt-3 text-sm text-slate-400">The demo runs in this browser tab using local storage — exactly like the extension, minus the website overlay.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[["#FFE066", "Sprint plan", "Ship v1.0, write docs, record demo…"], ["#74C0FC", "Research", "3 papers on spaced repetition to read"], ["#8CE99A", "Groceries", "☑ Oat milk  ☐ Coffee  ☐ Basil"], ["#FF8787", "Call mom", "Sunday 6 PM — remind weekly"]].map(([c, t, b], i) => (
              <div key={t} className="overflow-hidden rounded-2xl shadow-xl transition hover:-translate-y-1" style={{ marginTop: i % 2 ? 24 : 0 }}>
                <div className="px-3.5 py-2 font-bold" style={{ background: c, color: "#1f2328" }}>{t}</div>
                <div className="min-h-[84px] px-3.5 py-3 text-sm text-slate-900" style={{ background: `rgba(${rgb(c)}, .5)` }}>{b}</div>
                <div className="px-3.5 py-1.5 text-xs text-slate-800" style={{ background: c }}>example.com · #{["work", "study", "home", "family"][i]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* install */}
      <Section id="install" eyebrow="Installation" title="Up and running in under a minute">
        <div className="mx-auto max-w-3xl">
          <div className="mx-auto mb-8 flex w-fit rounded-xl bg-slate-100 p-1" role="tablist">
            {([["chrome", "Google Chrome"], ["edge", "Microsoft Edge"]] as const).map(([k, l]) => (
              <button key={k} role="tab" aria-selected={browser === k} onClick={() => setBrowser(k)} className={`rounded-lg px-5 py-2 text-sm font-bold transition ${browser === k ? "bg-white text-slate-900 shadow" : "text-slate-500 hover:text-slate-800"}`}>{l}</button>
            ))}
          </div>
          <ol className="space-y-4">
            {steps.map(([t, d], i) => (
              <li key={t} className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <span className="grid h-9 w-9 flex-none place-items-center rounded-full bg-amber-400 font-black text-slate-900">{i + 1}</span>
                <div><h3 className="font-bold text-slate-900">{t}</h3><p className="mt-0.5 text-slate-600">{d}</p></div>
              </li>
            ))}
          </ol>
          <div className="mt-8 flex flex-col items-center gap-3"><DownloadButton /><p className="text-sm text-slate-500">Version {VERSION} · ≈ 70 KB · Manifest V3 · works on Chrome/Edge 105+</p></div>
          <div className="mt-10 rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
            <b>Shortcuts:</b> <kbd className="rounded bg-white px-1.5 py-0.5 font-mono text-xs shadow">Alt+Shift+N</kbd> new note · <kbd className="rounded bg-white px-1.5 py-0.5 font-mono text-xs shadow">Alt+Shift+H</kbd> show/hide notes · <kbd className="rounded bg-white px-1.5 py-0.5 font-mono text-xs shadow">Ctrl+S</kbd> save · <kbd className="rounded bg-white px-1.5 py-0.5 font-mono text-xs shadow">Ctrl+F</kbd> find &amp; replace. Right-click selected text → “Add selection to a Skylab sticky note”.
          </div>
        </div>
      </Section>

      {/* security */}
      <section id="security" className="scroll-mt-20 bg-amber-50 px-5 py-20">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-center text-3xl font-extrabold text-slate-900 sm:text-4xl">Private by design</h2>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {[["🏠", "Local-first", "Notes live in chrome.storage.local and optionally in a folder you choose. No backend, no analytics, no accounts."], ["🛡️", "XSS-safe content", "Everything you type, paste, import or restore is passed through a strict allow-list sanitizer. The overlay is isolated in a closed Shadow DOM."], ["🔐", "Real encryption", "Locked notes use AES-256-GCM with a PBKDF2-SHA-256 key (200 000 rounds). Your password never leaves your device and cannot be recovered."]].map(([i, t, d]) => (
              <div key={t} className="rounded-2xl bg-white p-6 shadow-sm"><div className="text-3xl">{i}</div><h3 className="mt-3 text-lg font-bold text-slate-900">{t}</h3><p className="mt-1.5 text-slate-600">{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* changelog */}
      <Section id="changelog" eyebrow="Version log" title="What’s new">
        <div className="mx-auto max-w-3xl space-y-6">
          {LOGS.map((l) => (
            <article key={l.v} className="rounded-2xl border border-slate-200 p-6">
              <div className="flex flex-wrap items-center gap-3"><span className="rounded-full bg-slate-900 px-3 py-1 text-sm font-bold text-white">v{l.v}</span><span className="font-bold text-slate-900">{l.d}</span><span className="text-sm text-slate-400">Latest</span></div>
              <ul className="mt-4 list-disc space-y-1.5 pl-5 text-slate-600">{l.items.map((it) => (<li key={it}>{it}</li>))}</ul>
              <a href={ZIP} download className="mt-4 inline-block text-sm font-bold text-amber-700 hover:underline">Download v{l.v} →</a>
            </article>
          ))}
        </div>
      </Section>

      {/* faq */}
      <section id="faq" className="scroll-mt-20 bg-slate-50 px-5 py-20">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-center text-3xl font-extrabold text-slate-900 sm:text-4xl">Frequently asked questions</h2>
          <div className="mt-10 space-y-3">
            {FAQ.map(([q, a], i) => (
              <div key={q} className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                <button onClick={() => setFaq(faq === i ? null : i)} aria-expanded={faq === i} className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-bold text-slate-900 hover:bg-slate-50">
                  {q}<span className={`text-xl text-amber-600 transition ${faq === i ? "rotate-45" : ""}`}>+</span>
                </button>
                {faq === i && <p className="px-5 pb-5 text-slate-600">{a}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 py-20 text-center">
        <div className="mx-auto max-w-2xl rounded-3xl bg-gradient-to-br from-yellow-300 to-amber-400 p-10 shadow-xl">
          <h2 className="text-3xl font-black text-slate-900">Stop losing context. Start sticking notes.</h2>
          <p className="mt-2 text-slate-800">Free, private and ready in a minute.</p>
          <a href={ZIP} download className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-7 py-3.5 font-bold text-white transition hover:bg-slate-700 active:scale-95">Download Skylab Sticky Note</a>
        </div>
      </section>

      <footer className="border-t border-slate-200 px-5 py-8 text-center text-sm text-slate-500">
        <p>© {new Date().getFullYear()} Skylab Sticky Note · v{VERSION} · Built for Chrome, Edge &amp; Chromium browsers</p>
        <p className="mt-1">Your notes never leave your device.</p>
      </footer>
    </div>
  );
}
