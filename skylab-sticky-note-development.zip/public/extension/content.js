/* Skylab Sticky Note – content script (floating overlay) */
(function () {
  'use strict';
  if (window.top !== window || window.__skylabSticky) return;
  window.__skylabSticky = true;
  const SL = window.SL; const h = SL.h;

  let host; let shadow; let layer; let fab; let badge; let menu = null; let settings = Object.assign({}, SL.DEFAULTS);
  const windows = new Map(); let hiddenAll = false; let curUrl = location.href; let ready = false; let pageCount = 0;

  /* Keep page hotkeys from firing while typing inside our UI (best effort). */
  const guard = (e) => { if (!host) return; const p = e.composedPath ? e.composedPath() : []; if (p.includes(host)) e.stopImmediatePropagation(); };
  ['keydown', 'keyup', 'keypress'].forEach((t) => window.addEventListener(t, guard, true));

  const safe = (fn) => { try { return fn(); } catch (e) { return undefined; } };
  const send = (msg) => safe(() => chrome.runtime.sendMessage(msg));

  function build() {
    host = document.createElement('div');
    host.id = 'skylab-sticky-note-root';
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
    shadow = host.attachShadow({ mode: 'closed' });
    const link = document.createElement('link'); link.rel = 'stylesheet'; link.href = chrome.runtime.getURL('note.css');
    layer = h('div', { class: 'sl-layer' }); layer.style.visibility = 'hidden';
    const show = () => { layer.style.visibility = 'visible'; };
    link.addEventListener('load', show); link.addEventListener('error', show); setTimeout(show, 1500);
    shadow.append(link, layer);
    SL.ui.setLayer(layer);
    (document.documentElement || document.body).append(host);
    SL.ui.openNoteHandler = openById;
    buildFab();
  }

  /* ------------------------------------------------------------ floating icon */
  function buildFab() {
    badge = h('span', { class: 'sl-fab-badge', hidden: true });
    fab = h('button', { class: 'sl-fab', type: 'button', title: 'Skylab Sticky Note', 'aria-label': 'Skylab Sticky Note menu', html: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3Z"/><path d="M15 3v5.5H21"/><path d="M8 13h8M8 17h5"/></svg>' }, badge);
    layer.append(fab); placeFab();
    let sx; let sy; let ox; let oy; let moved = false; let down = false;
    fab.addEventListener('pointerdown', (e) => { if (e.button !== 0) return; down = true; moved = false; sx = e.clientX; sy = e.clientY; const r = fab.getBoundingClientRect(); ox = r.left; oy = r.top; fab.setPointerCapture(e.pointerId); });
    fab.addEventListener('pointermove', (e) => {
      if (!down) return; if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 5) moved = true;
      if (moved) { closeMenu(); settings.iconPos = { x: SL.clamp(ox + e.clientX - sx, 4, innerWidth - 50), y: SL.clamp(oy + e.clientY - sy, 4, innerHeight - 50) }; placeFab(); }
    });
    fab.addEventListener('pointerup', () => { if (!down) return; down = false; if (moved) { SL.settings.set({ iconPos: settings.iconPos }); } else toggleMenu(); });
    fab.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleMenu(); } });
    applyIconVisibility();
  }
  function placeFab() {
    const p = settings.iconPos; const x = p ? SL.clamp(p.x, 4, innerWidth - 50) : innerWidth - 66; const y = p ? SL.clamp(p.y, 4, innerHeight - 50) : innerHeight - 76;
    fab.style.left = x + 'px'; fab.style.top = y + 'px';
  }
  function applyIconVisibility() { fab.style.display = settings.showIcon ? '' : 'none'; if (!settings.showIcon) closeMenu(); }
  function updateBadge() {
    const open = pageCount; badge.hidden = open === 0; badge.textContent = open > 99 ? '99+' : String(open);
  }
  function closeMenu() { if (menu) { menu.remove(); menu = null; layer.removeEventListener('pointerdown', outside, true); } }
  function outside(e) { const p = e.composedPath(); if (menu && !p.includes(menu) && !p.includes(fab)) closeMenu(); }
  async function toggleMenu() {
    if (menu) { closeMenu(); return; }
    const list = (await SL.notes.forUrl(location.href)).sort((a, b) => b.updatedAt - a.updatedAt);
    const items = list.length ? list.map((n) => h('button', { class: 'sl-fm-item', type: 'button', onclick: () => { closeMenu(); openNote(n, true); } },
      h('span', { class: 'sl-fm-dot', style: { background: n.color } }), h('span', { class: 't', text: n.locked ? '🔒 ' + (n.title || 'Locked note') : (n.title || SL.textOf(n.html).slice(0, 40) || 'Untitled') }), h('small', { text: windows.has(n.id) ? 'open' : 'hidden' })))
      : [h('div', { class: 'sl-fm-empty', text: 'No notes on this page yet.' })];
    menu = h('div', { class: 'sl-fabmenu', role: 'menu' },
      h('div', { class: 'sl-fabmenu-h' }, h('div', null, h('b', { text: 'Skylab Sticky Note' }), h('small', { text: SL.host(location.href) || 'This page' }))),
      h('button', { class: 'sl-btn primary sm sl-fm-new', type: 'button', text: '+ New note on this page', onclick: () => { closeMenu(); createNote(''); } }),
      h('div', { class: 'sl-fm-list' }, items),
      h('button', { class: 'sl-fm-item', type: 'button', html: SL.icon(hiddenAll ? 'eye' : 'eyeOff', 15) + '<span class="t">' + (hiddenAll ? 'Show all notes' : 'Hide all notes') + '</span>', onclick: () => { closeMenu(); toggleHidden(); } }),
      h('button', { class: 'sl-fm-item', type: 'button', html: SL.icon('grid', 15) + '<span class="t">Open All Notes dashboard</span>', onclick: () => { closeMenu(); send({ type: 'open-dashboard' }); } }),
      h('button', { class: 'sl-fm-item', type: 'button', html: SL.icon('eyeOff', 15) + '<span class="t">Don’t show icon on websites</span>', onclick: async () => { closeMenu(); await SL.settings.set({ showIcon: false }); SL.ui.toast('Icon hidden. Turn it back on from the extension popup.', { ms: 4000 }); } }));
    const r = fab.getBoundingClientRect();
    layer.append(menu);
    const mw = menu.offsetWidth; const mh = menu.offsetHeight;
    menu.style.left = SL.clamp(r.left + r.width / 2 - mw / 2, 8, innerWidth - mw - 8) + 'px';
    menu.style.top = (r.top > mh + 16 ? r.top - mh - 10 : Math.min(r.bottom + 10, innerHeight - mh - 8)) + 'px';
    layer.addEventListener('pointerdown', outside, true);
  }

  /* ----------------------------------------------------------------- notes */
  function applyVisibility() {
    windows.forEach((w) => { w.root.style.display = hiddenAll && !w.note.pinned ? 'none' : ''; });
  }
  function toggleHidden() {
    hiddenAll = !hiddenAll; applyVisibility(); SL.ui.toast(hiddenAll ? 'Notes hidden on this page (pinned notes stay)' : 'Notes shown');
  }
  function openNote(n, focus) {
    let w = windows.get(n.id);
    if (hiddenAll) { hiddenAll = false; applyVisibility(); }
    if (w) { w.root.style.display = ''; if (focus) w.focus(); return w; }
    if (n.open === false) { n.open = true; n.rev = (n.rev || 0) + 1; SL.notes.save(n); }
    w = new SL.NoteWindow(n, {
      mode: 'float', parent: layer,
      autoSave: () => settings.autoSave !== false,
      allTags: async () => Array.from(new Set((await SL.notes.all()).flatMap((x) => x.tags || []))),
      onClose: (win) => { windows.delete(win.note.id); refreshCount(); },
      onDeleted: (id) => { windows.delete(id); refreshCount(); }
    });
    windows.set(n.id, w); w.bump(); if (focus) w.focus();
    return w;
  }
  async function openById(id) {
    const n = await SL.notes.get(id);
    if (n && SL.notes.matches(n, location.href)) openNote(n, true); else send({ type: 'open-dashboard', id });
  }
  async function refreshCount() { pageCount = (await SL.notes.forUrl(location.href)).length; updateBadge(); }
  async function refreshAll() {
    const list = await SL.notes.forUrl(location.href); pageCount = list.length;
    windows.forEach((w, id) => { if (!list.find((n) => n.id === id)) { w.destroy(); windows.delete(id); } });
    list.forEach((n) => { if (!windows.has(n.id) && n.open !== false) openNote(n, false); });
    updateBadge();
  }
  async function createNote(text) {
    const sel = String(window.getSelection ? window.getSelection().toString() : '').trim();
    const raw = (text || sel || '').slice(0, 20000);
    const count = windows.size;
    const w = 340; const hh = 380;
    const n = SL.notes.create({
      url: location.href, pageTitle: document.title || '', scope: settings.defaultScope || 'url', color: settings.defaultColor || '#FFE066',
      title: raw ? raw.split('\n')[0].slice(0, 48) : '',
      html: raw ? raw.split('\n').map((l) => '<div>' + (SL.esc(l) || '<br>') + '</div>').join('') : '',
      x: Math.max(12, innerWidth - w - 40 - (count % 6) * 26), y: Math.max(12, 70 + (count % 6) * 26), w: Math.min(w, innerWidth - 24), h: Math.min(hh, innerHeight - 24)
    });
    await SL.notes.save(n); pageCount += 1; updateBadge();
    const win = openNote(n, true);
    setTimeout(() => { if (win && !raw) win.titleEl.focus(); }, 60);
    return win;
  }

  /* --------------------------------------------------------------- listeners */
  function onStorage(ch) {
    Object.keys(ch).forEach((k) => {
      if (k === 'sl_settings') {
        const nv = Object.assign({}, SL.DEFAULTS, ch[k].newValue || {}); settings = nv; applyIconVisibility(); if (fab) placeFab();
      } else if (k.startsWith(SL.notes.P)) {
        const id = k.slice(SL.notes.P.length); const nv = ch[k].newValue; const w = windows.get(id);
        if (!nv) { if (w) { w.destroy(); windows.delete(id); } }
        else if (SL.notes.matches(nv, location.href)) {
          if (w) { if (nv.open === false && !w.dirty) { w.destroy(); windows.delete(id); } else w.applyRemote(nv); }
          else if (nv.open !== false && ready) openNote(nv, false);
        } else if (w) { w.destroy(); windows.delete(id); }
      }
    });
    clearTimeout(onStorage.t); onStorage.t = setTimeout(refreshCount, 200);
  }
  function onMessage(msg, _s, respond) {
    if (!msg || !msg.type) return;
    if (msg.type === 'ping') { respond({ ok: true }); return; }
    if (msg.type === 'new-note') { createNote(''); respond({ ok: true }); }
    else if (msg.type === 'text-to-note') { createNote(msg.text || ''); respond({ ok: true }); }
    else if (msg.type === 'toggle-notes') { toggleHidden(); respond({ ok: true }); }
    else if (msg.type === 'open-note') { openById(msg.id); respond({ ok: true }); }
    else if (msg.type === 'refresh') { refreshAll(); respond({ ok: true }); }
  }
  function checkUrl() {
    if (location.href !== curUrl) { curUrl = location.href; refreshAll(); }
  }
  function flushAll() { windows.forEach((w) => { w.flush(); }); }

  async function init() {
    if (!document.documentElement) return;
    settings = await SL.settings.get();
    build();
    await refreshAll(); ready = true;
    SL.store.onChanged(onStorage);
    chrome.runtime.onMessage.addListener(onMessage);
    setInterval(checkUrl, 800);
    window.addEventListener('popstate', checkUrl); window.addEventListener('hashchange', checkUrl);
    window.addEventListener('resize', () => { windows.forEach((w) => w.place()); if (fab) placeFab(); });
    window.addEventListener('pagehide', flushAll);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushAll(); });
  }
  const start = () => { try { init(); } catch (e) { /* page without body etc. */ } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
