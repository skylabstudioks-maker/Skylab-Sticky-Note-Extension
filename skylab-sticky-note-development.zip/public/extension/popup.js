/* Skylab Sticky Note – popup */
(async function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const manifest = chrome.runtime.getManifest();
  $('ver').textContent = 'v' + manifest.version;

  let settings = await SL.settings.get();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const pageOk = !!(tab && /^https?:/i.test(tab.url || ''));

  function paintSeg() {
    $('iconOn').setAttribute('aria-checked', String(!!settings.showIcon));
    $('iconOff').setAttribute('aria-checked', String(!settings.showIcon));
  }
  async function setIcon(v) { settings = await SL.settings.set({ showIcon: v }); paintSeg(); }
  $('iconOn').onclick = () => setIcon(true);
  $('iconOff').onclick = () => setIcon(false);
  paintSeg();

  const openDash = (hash) => { chrome.tabs.create({ url: chrome.runtime.getURL('notes.html') + (hash || '') }); window.close(); };
  const toPage = (payload) => chrome.runtime.sendMessage({ type: 'inject', tabId: tab.id, payload });

  $('newNote').onclick = () => { if (!pageOk) { openDash('#new'); return; } toPage({ type: 'new-note' }); setTimeout(() => window.close(), 80); };
  $('openDash').onclick = () => openDash('');
  $('openSettings').onclick = () => openDash('#settings');
  $('toggleHere').onclick = () => { if (!pageOk) return; chrome.tabs.sendMessage(tab.id, { type: 'toggle-notes' }).catch(() => {}); window.close(); };
  if (!pageOk) { $('toggleHere').disabled = true; $('toggleHere').style.opacity = '.5'; }

  const list = $('pageNotes');
  async function loadNotes() {
    const all = await SL.notes.all();
    $('stats').textContent = all.length + (all.length === 1 ? ' note' : ' notes') + ' · stored locally';
    list.textContent = '';
    if (!pageOk) { $('pageCount').textContent = '0'; $('pageHint').textContent = 'Notes can’t be placed on this kind of page. Use “New note” to write in the dashboard.'; return; }
    const notes = all.filter((n) => SL.notes.matches(n, tab.url)).sort((a, b) => b.updatedAt - a.updatedAt);
    $('pageCount').textContent = String(notes.length);
    $('pageHint').textContent = notes.length ? '' : 'Nothing here yet — click “New note” to pin one to this page.';
    notes.forEach((n) => {
      const b = document.createElement('button'); b.className = 'item'; b.type = 'button';
      const dot = document.createElement('span'); dot.className = 'dot'; dot.style.background = n.color;
      const t = document.createElement('span'); t.className = 't'; t.textContent = (n.locked ? '🔒 ' : '') + (n.title || (n.locked ? 'Locked note' : SL.textOf(n.html).slice(0, 40)) || 'Untitled');
      const s = document.createElement('small'); s.textContent = SL.timeAgo(n.updatedAt);
      b.append(dot, t, s);
      b.onclick = () => { toPage({ type: 'open-note', id: n.id }); setTimeout(() => window.close(), 80); };
      list.append(b);
    });
  }
  loadNotes();

  /* silently mirror changed notes into the user's chosen folder, if any */
  if (settings.folderEnabled && SL.folder && SL.folder.supported) { SL.folder.syncChanged().catch(() => {}); }
})();
