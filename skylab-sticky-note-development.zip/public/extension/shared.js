/* Skylab Sticky Note – shared core (storage, sanitizer, crypto, helpers) */
(function (g) {
  'use strict';
  const SL = (g.SL = g.SL || {});
  const ext = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local ? chrome : null;
  SL.isExt = !!ext;
  SL.hasRuntime = !!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id);
  SL.VERSION = '1.0.0';

  /* ---------------------------------------------------------------- storage */
  const LS = 'skylab:';
  const localListeners = new Set();
  function lsRead(k) {
    try { return JSON.parse(localStorage.getItem(LS + k)); } catch (e) { return undefined; }
  }
  function emit(changes) { localListeners.forEach((cb) => { try { cb(changes); } catch (e) { /* ignore */ } }); }

  SL.store = {
    async get(keys) {
      if (ext) return ext.storage.local.get(keys);
      const out = {};
      if (keys == null) {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(LS)) out[k.slice(LS.length)] = lsRead(k.slice(LS.length));
        }
        return out;
      }
      (typeof keys === 'string' ? [keys] : keys).forEach((k) => { const v = lsRead(k); if (v !== undefined && v !== null) out[k] = v; });
      return out;
    },
    async set(obj) {
      if (ext) return ext.storage.local.set(obj);
      const changes = {};
      Object.keys(obj).forEach((k) => {
        changes[k] = { oldValue: lsRead(k), newValue: obj[k] };
        localStorage.setItem(LS + k, JSON.stringify(obj[k]));
      });
      emit(changes);
    },
    async remove(keys) {
      if (ext) return ext.storage.local.remove(keys);
      const changes = {};
      (typeof keys === 'string' ? [keys] : keys).forEach((k) => {
        changes[k] = { oldValue: lsRead(k) };
        localStorage.removeItem(LS + k);
      });
      emit(changes);
    },
    onChanged(cb) {
      if (ext) { chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local') cb(ch); }); return; }
      localListeners.add(cb);
      window.addEventListener('storage', (e) => {
        if (!e.key || !e.key.startsWith(LS)) return;
        const k = e.key.slice(LS.length);
        cb({ [k]: { oldValue: e.oldValue ? JSON.parse(e.oldValue) : undefined, newValue: e.newValue ? JSON.parse(e.newValue) : undefined } });
      });
    },
    async bytes() {
      try {
        if (ext && ext.storage.local.getBytesInUse) return await ext.storage.local.getBytesInUse(null);
        let n = 0; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith(LS)) n += (k.length + localStorage.getItem(k).length) * 2; } return n;
      } catch (e) { return 0; }
    }
  };

  /* ---------------------------------------------------------------- helpers */
  SL.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  SL.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  SL.clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  SL.COLORS = [
    { name: 'Yellow', hex: '#FFE066' }, { name: 'Blue', hex: '#74C0FC' }, { name: 'Red', hex: '#FF8787' },
    { name: 'Green', hex: '#8CE99A' }, { name: 'Black', hex: '#212529' }, { name: 'White', hex: '#FFFFFF' }
  ];
  SL.hexToRgb = (hex) => {
    let h = String(hex || '#FFE066').replace('#', '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    const n = parseInt(h, 16);
    if (isNaN(n)) return [255, 224, 102];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  };
  SL.contrast = (hex) => {
    const [r, g2, b] = SL.hexToRgb(hex);
    return (0.2126 * r + 0.7152 * g2 + 0.0722 * b) / 255 > 0.5 ? '#1f2328' : '#ffffff';
  };
  SL.isHex = (s) => /^#[0-9a-f]{6}$/i.test(String(s || ''));
  SL.normUrl = (u) => { try { const x = new URL(u); x.hash = ''; return x.href.replace(/\/$/, ''); } catch (e) { return String(u || ''); } };
  SL.host = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
  SL.shortUrl = (u, max = 38) => {
    try { const x = new URL(u); const s = x.hostname.replace(/^www\./, '') + (x.pathname === '/' ? '' : x.pathname) + x.search; return s.length > max ? s.slice(0, max - 1) + '…' : s; } catch (e) { return u || ''; }
  };
  SL.fmtEdited = (ts) => 'Edited at ' + new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  SL.fmtDateTime = (ts) => new Date(ts).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  SL.timeAgo = (ts) => {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 45) return 'Just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    if (s < 86400 * 7) return Math.round(s / 86400) + ' d ago';
    return new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric', year: new Date(ts).getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
  };
  SL.textOf = (html) => {
    if (!html) return '';
    const s = String(html).replace(/<img[^>]*>/gi, ' ').replace(/<\/(div|p|li|h[1-6]|tr)>|<br\s*\/?>/gi, '\n').replace(/<\/t[dh]>/gi, '\t');
    const doc = new DOMParser().parseFromString(s, 'text/html');
    return (doc.body.textContent || '').replace(/\u200b/g, '').replace(/\n{3,}/g, '\n\n').trim();
  };

  /* -------------------------------------------------------------- sanitizer */
  const ALLOWED = new Set('A B BLOCKQUOTE BR CODE DEL DIV EM FONT H1 H2 H3 HR I IMG INPUT LI OL P PRE S SPAN STRIKE STRONG SUB SUP TABLE TBODY TD TFOOT TH THEAD TR U UL'.split(' '));
  const DROP = new Set('SCRIPT STYLE IFRAME OBJECT EMBED LINK META SVG MATH FORM TEXTAREA SELECT BUTTON NOSCRIPT TEMPLATE TITLE HEAD CANVAS VIDEO AUDIO SOURCE APPLET BASE FRAME FRAMESET'.split(' '));
  const CLASSES = new Set(['sl-check', 'sl-done', 'sl-ct', 'sl-img', 'sl-table']);
  const STYLE_OK = new Set(['color', 'background-color', 'font-size', 'font-family', 'font-weight', 'font-style', 'text-decoration', 'text-decoration-line', 'text-align', 'width', 'height']);
  const SAFE_URL = /^(https?:|mailto:|tel:)/i;
  const SAFE_IMG = /^(data:image\/(png|jpe?g|gif|webp|bmp);base64,[a-z0-9+/=]+$|https:\/\/)/i;

  function cleanStyle(s) {
    return String(s).split(';').map((d) => d.trim()).filter(Boolean).map((decl) => {
      const i = decl.indexOf(':'); if (i < 0) return '';
      const p = decl.slice(0, i).trim().toLowerCase(); const v = decl.slice(i + 1).trim();
      if (!STYLE_OK.has(p) || v.length > 140) return '';
      if (/url\(|expression|javascript|@import|[<>\\]/i.test(v)) return '';
      return p + ': ' + v;
    }).filter(Boolean).join('; ');
  }
  function clean(parent) {
    Array.from(parent.childNodes).forEach((node) => {
      if (node.nodeType === 3) return;
      if (node.nodeType !== 1) { node.remove(); return; }
      const tag = node.tagName;
      if (DROP.has(tag)) { node.remove(); return; }
      clean(node);
      if (!ALLOWED.has(tag)) { node.replaceWith(...Array.from(node.childNodes)); return; }
      Array.from(node.attributes).forEach((a) => {
        const name = a.name.toLowerCase(); const v = a.value; let ok = false;
        if (name === 'class') {
          const cl = v.split(/\s+/).filter((c) => CLASSES.has(c)).join(' ');
          if (cl) { node.setAttribute('class', cl); ok = true; }
        } else if (name === 'style') {
          const st = cleanStyle(v); if (st) { node.setAttribute('style', st); ok = true; }
        } else if (name === 'href') ok = tag === 'A' && SAFE_URL.test(v.trim());
        else if (name === 'src') ok = tag === 'IMG' && SAFE_IMG.test(v.trim());
        else if (name === 'alt') ok = tag === 'IMG';
        else if (name === 'type') ok = tag === 'INPUT' && v === 'checkbox';
        else if (name === 'checked') ok = tag === 'INPUT';
        else if (name === 'colspan' || name === 'rowspan') ok = (tag === 'TD' || tag === 'TH') && /^\d{1,2}$/.test(v);
        else if (name === 'face' || name === 'size' || name === 'color') ok = tag === 'FONT' && v.length < 140 && !/[<>]/.test(v);
        if (!ok) node.removeAttribute(a.name);
      });
      if (tag === 'INPUT' && node.getAttribute('type') !== 'checkbox') { node.remove(); return; }
      if (tag === 'IMG' && !node.getAttribute('src')) { node.remove(); return; }
      if (tag === 'A') {
        if (!node.getAttribute('href')) { node.replaceWith(...Array.from(node.childNodes)); return; }
        node.setAttribute('target', '_blank'); node.setAttribute('rel', 'noopener noreferrer nofollow');
      }
    });
  }
  SL.sanitize = (html) => {
    if (!html) return '';
    const doc = new DOMParser().parseFromString('<body>' + html, 'text/html');
    clean(doc.body);
    return doc.body.innerHTML;
  };
  SL.checkHtml = (text, done) => '<div class="sl-check' + (done ? ' sl-done' : '') + '"><input type="checkbox"' + (done ? ' checked' : '') + '><span class="sl-ct">' + (SL.esc(text) || '\u200b') + '</span></div>';

  /* ----------------------------------------------------------------- crypto */
  const te = new TextEncoder(); const td = new TextDecoder();
  const b64 = (buf) => { const a = new Uint8Array(buf); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode.apply(null, a.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  let keyCache = null;
  const ITER = 200000;
  async function deriveKey(pw, salt, iter) {
    if (!g.crypto || !g.crypto.subtle) throw new Error('NO_SUBTLE');
    const sb = b64(salt);
    if (keyCache && keyCache.pw === pw && keyCache.sb === sb && keyCache.it === iter) return keyCache.key;
    const km = await crypto.subtle.importKey('raw', te.encode(pw), 'PBKDF2', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    keyCache = { pw, sb, it: iter, key };
    return key;
  }
  SL.canEncrypt = () => !!(g.crypto && g.crypto.subtle);
  SL.encrypt = async (plain, pw, saltB64) => {
    const salt = saltB64 ? unb64(saltB64) : crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKey(pw, salt, ITER);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te.encode(plain));
    return { v: 1, alg: 'AES-GCM-256/PBKDF2-SHA256', it: ITER, s: b64(salt), iv: b64(iv), d: b64(ct) };
  };
  SL.decrypt = async (c, pw) => {
    const key = await deriveKey(pw, unb64(c.s), c.it || ITER);
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(c.iv) }, key, unb64(c.d));
    return td.decode(pt);
  };

  /* --------------------------------------------------------------- settings */
  SL.DEFAULTS = { showIcon: true, autoSave: true, defaultColor: '#FFE066', defaultScope: 'url', theme: 'auto', notifications: true, folderEnabled: false, folderSyncedAt: 0, iconPos: null, layout: 'grid', sort: 'updated', welcomed: false };
  SL.settings = {
    async get() { const r = await SL.store.get('sl_settings'); return Object.assign({}, SL.DEFAULTS, r.sl_settings || {}); },
    async set(p) { const cur = await SL.settings.get(); const nx = Object.assign(cur, p); await SL.store.set({ sl_settings: nx }); return nx; }
  };

  /* ------------------------------------------------------------------ notes */
  const P = 'note:';
  const SCOPES = ['url', 'domain', 'global', 'none'];
  function linkMatch(p, u) {
    p = String(p || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '');
    if (!p) return false;
    const cur = (u.hostname + u.pathname + u.search).toLowerCase().replace(/^www\./, '').replace(/\/$/, '');
    if (p.includes('/')) return cur.startsWith(p.replace(/\/$/, ''));
    const hn = u.hostname.toLowerCase().replace(/^www\./, '');
    return hn === p || hn.endsWith('.' + p);
  }
  SL.notes = {
    P,
    isKey: (k) => k.startsWith(P),
    async all() { const all = await SL.store.get(null); return Object.keys(all).filter((k) => k.startsWith(P)).map((k) => all[k]).filter(Boolean); },
    async get(id) { const r = await SL.store.get(P + id); return r[P + id] || null; },
    async save(n) { await SL.store.set({ [P + n.id]: n }); return n; },
    async remove(id) { await SL.store.remove(P + id); },
    create(o) {
      const now = Date.now();
      return Object.assign({
        id: SL.uid(), title: '', html: '', color: '#FFE066', textColor: '', url: '', pageTitle: '', scope: 'url', links: [], tags: [],
        x: 60, y: 80, w: 340, h: 380, pinned: false, open: true, archived: false, toolbarHidden: false, locked: false, cipher: null,
        reminder: null, versions: [], createdAt: now, updatedAt: now, rev: 1
      }, o || {});
    },
    normalize(o) {
      const n = SL.notes.create({});
      const s = (v, d) => (typeof v === 'string' ? v : d);
      n.title = s(o.title, '').slice(0, 200);
      n.html = SL.sanitize(s(o.html, ''));
      n.color = SL.isHex(o.color) ? o.color : n.color;
      n.textColor = SL.isHex(o.textColor) ? o.textColor : '';
      n.url = /^https?:\/\//i.test(s(o.url, '')) ? o.url : '';
      n.pageTitle = s(o.pageTitle, '').slice(0, 300);
      n.scope = SCOPES.includes(o.scope) && (o.scope === 'none' || o.scope === 'global' || n.url) ? o.scope : (n.url ? 'url' : 'none');
      n.links = Array.isArray(o.links) ? o.links.map(String).slice(0, 50) : [];
      n.tags = Array.isArray(o.tags) ? Array.from(new Set(o.tags.map((t) => String(t).trim().slice(0, 40)).filter(Boolean))).slice(0, 30) : [];
      n.w = SL.clamp(+o.w || 340, 260, 1400); n.h = SL.clamp(+o.h || 380, 180, 1400);
      n.x = +o.x || 60; n.y = +o.y || 80;
      n.pinned = !!o.pinned; n.archived = !!o.archived; n.open = o.open !== false; n.toolbarHidden = !!o.toolbarHidden;
      if (o.locked && o.cipher && o.cipher.d && o.cipher.iv && o.cipher.s) { n.locked = true; n.cipher = { v: 1, alg: String(o.cipher.alg || ''), it: +o.cipher.it || 200000, s: String(o.cipher.s), iv: String(o.cipher.iv), d: String(o.cipher.d) }; n.html = ''; }
      if (o.reminder && +o.reminder.at) n.reminder = { at: +o.reminder.at, repeat: ['none', 'daily', 'weekdays', 'weekly', 'monthly', 'yearly'].includes(o.reminder.repeat) ? o.reminder.repeat : 'none', message: s(o.reminder.message, '').slice(0, 300), fired: !!o.reminder.fired };
      n.createdAt = +o.createdAt || Date.now(); n.updatedAt = +o.updatedAt || n.createdAt;
      return n;
    },
    duplicate(n) {
      const c = SL.notes.create(JSON.parse(JSON.stringify(n)));
      const now = Date.now();
      Object.assign(c, { id: SL.uid(), title: (n.title || 'Untitled') + ' (copy)', x: n.x + 28, y: n.y + 28, createdAt: now, updatedAt: now, versions: [], rev: 1, pinned: false, reminder: null, open: true });
      return c;
    },
    matches(n, url) {
      if (!n || n.archived) return false;
      if (n.scope === 'global') return true;
      let u; try { u = new URL(url); } catch (e) { return false; }
      if (n.scope === 'domain' && n.url && SL.host(n.url) === SL.host(url)) return true;
      if (n.scope === 'url' && n.url && SL.normUrl(n.url) === SL.normUrl(url)) return true;
      return (n.links || []).some((p) => linkMatch(p, u));
    },
    async forUrl(url) { return (await SL.notes.all()).filter((n) => SL.notes.matches(n, url)); }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
