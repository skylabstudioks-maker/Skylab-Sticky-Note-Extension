/* Skylab Sticky Note – background service worker (MV3) */
'use strict';
const NOTE_PREFIX = 'note:';
const CONTENT_FILES = ['shared.js', 'formats.js', 'editor.js', 'content.js'];
const dashboardUrl = (hash) => chrome.runtime.getURL('notes.html') + (hash || '');

/* ------------------------------------------------------------- menus & setup */
function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'sl-selection', title: 'Add selection to a Skylab sticky note', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'sl-new', title: 'New Skylab sticky note on this page', contexts: ['page', 'frame'] });
    chrome.contextMenus.create({ id: 'sl-dashboard', title: 'Open All Notes dashboard', contexts: ['action'] });
  });
}
function ensureAlarm() { chrome.alarms.create('sl-tick', { periodInMinutes: 1 }); }

chrome.runtime.onInstalled.addListener((d) => {
  createMenus(); ensureAlarm(); scheduleReminders();
  if (d.reason === 'install') chrome.tabs.create({ url: dashboardUrl('#welcome') });
});
chrome.runtime.onStartup.addListener(() => { ensureAlarm(); scheduleReminders(); });

/* ----------------------------------------------- talking to the content script */
async function sendToTab(tab, msg, fallbackHash) {
  if (!tab || tab.id == null) return;
  try { await chrome.tabs.sendMessage(tab.id, msg); return; } catch (e) { /* not injected yet */ }
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: CONTENT_FILES });
    await new Promise((r) => setTimeout(r, 350));
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch (e) {
    // restricted page (chrome://, store, PDF viewer…) – use the dashboard instead
    let hash = fallbackHash || '#new';
    if (msg.type === 'text-to-note' && msg.text) hash = '#new=' + encodeURIComponent(String(msg.text).slice(0, 4000));
    chrome.tabs.create({ url: dashboardUrl(hash) });
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'sl-selection') sendToTab(tab, { type: 'text-to-note', text: info.selectionText || '' });
  else if (info.menuItemId === 'sl-new') sendToTab(tab, { type: 'new-note' });
  else if (info.menuItemId === 'sl-dashboard') chrome.tabs.create({ url: dashboardUrl() });
});

chrome.commands.onCommand.addListener(async (cmd) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (cmd === 'new-note') sendToTab(tab, { type: 'new-note' });
  else if (cmd === 'toggle-notes') { try { await chrome.tabs.sendMessage(tab.id, { type: 'toggle-notes' }); } catch (e) { /* no notes on this page */ } }
});

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg) return;
  if (msg.type === 'open-dashboard') {
    chrome.tabs.create({ url: dashboardUrl(msg.id ? '#note=' + msg.id : msg.hash || '') });
    respond({ ok: true });
  } else if (msg.type === 'inject') {
    sendToTab({ id: msg.tabId }, msg.payload).then(() => respond({ ok: true }));
    return true;
  }
});

/* ------------------------------------------------------------------ reminders */
function nextOccurrence(r) {
  if (!r.repeat || r.repeat === 'none') return null;
  const d = new Date(r.at); const now = Date.now(); let guard = 0;
  while (d.getTime() <= now && guard++ < 4000) {
    if (r.repeat === 'daily') d.setDate(d.getDate() + 1);
    else if (r.repeat === 'weekdays') { do { d.setDate(d.getDate() + 1); } while (d.getDay() === 0 || d.getDay() === 6); }
    else if (r.repeat === 'weekly') d.setDate(d.getDate() + 7);
    else if (r.repeat === 'monthly') d.setMonth(d.getMonth() + 1);
    else if (r.repeat === 'yearly') d.setFullYear(d.getFullYear() + 1);
    else return null;
  }
  return d.getTime();
}
const stripTags = (html) => String(html || '').replace(/<img[^>]*>/gi, ' ').replace(/<\/(div|p|li|h\d)>|<br\s*\/?>/gi, ' ').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();

async function fire(n, settings) {
  const title = n.title || 'Sticky note reminder';
  const message = (n.reminder && n.reminder.message) || (n.locked ? 'A locked note has a reminder.' : stripTags(n.html).slice(0, 140)) || 'Your note reminder is due.';
  if (settings.notifications !== false) {
    chrome.notifications.create('sl:' + n.id + ':' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '⏰ ' + title, message, priority: 2, requireInteraction: true });
  }
  const tabs = await chrome.tabs.query({ active: true });
  tabs.forEach((t) => { chrome.tabs.sendMessage(t.id, { type: 'reminder', note: { id: n.id, title, message } }).catch(() => {}); });
}
let checking = false;
async function checkReminders() {
  if (checking) return; checking = true;
  try {
    const all = await chrome.storage.local.get(null); const settings = all.sl_settings || {}; const now = Date.now();
    for (const k of Object.keys(all)) {
      if (!k.startsWith(NOTE_PREFIX)) continue;
      const n = all[k]; const r = n && n.reminder;
      if (!r || !r.at || r.fired || r.at > now + 1500) continue;
      await fire(n, settings);
      const nx = nextOccurrence(r);
      if (nx) r.at = nx; else r.fired = true;
      r.lastFired = now; n.rev = (n.rev || 0) + 1;
      await chrome.storage.local.set({ [k]: n });
    }
    scheduleReminders(all);
  } finally { checking = false; }
}
async function scheduleReminders(all) {
  all = all || (await chrome.storage.local.get(null)); const now = Date.now();
  Object.keys(all).forEach((k) => {
    if (!k.startsWith(NOTE_PREFIX)) return; const r = all[k] && all[k].reminder;
    if (r && r.at && !r.fired && r.at > now) chrome.alarms.create('sl-rem:' + all[k].id, { when: r.at });
  });
}
let schedTimer = null;
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'sl-tick' || a.name.startsWith('sl-rem:')) checkReminders(); });
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  if (Object.keys(ch).some((k) => k.startsWith(NOTE_PREFIX) && ch[k].newValue && ch[k].newValue.reminder)) { clearTimeout(schedTimer); schedTimer = setTimeout(() => scheduleReminders(), 400); }
});
chrome.notifications.onClicked.addListener((id) => {
  const m = id.match(/^sl:([^:]+):/); chrome.notifications.clear(id);
  chrome.tabs.create({ url: dashboardUrl(m ? '#note=' + m[1] : '') });
});
