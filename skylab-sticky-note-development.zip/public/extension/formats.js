/* Skylab Sticky Note – export / import formats (.json .md .doc .sheet .notepad) */
(function (g) {
  'use strict';
  const SL = g.SL;
  const F = (SL.fmt = {});
  F.FORMATS = [
    { id: 'json', label: 'JSON (.json)', ext: 'json', desc: 'Full backup incl. text, colors and CSS' },
    { id: 'md', label: 'Markdown (.md)', ext: 'md', desc: 'Portable text with formatting' },
    { id: 'doc', label: 'Word (.doc)', ext: 'doc', desc: 'Opens in Word, Pages, Docs' },
    { id: 'sheet', label: 'Sheet (.sheet)', ext: 'sheet', desc: 'CSV-style rows: tables & lists' },
    { id: 'notepad', label: 'Notepad (.notepad)', ext: 'notepad', desc: 'Plain text with a header' }
  ];

  const parseHtml = (html) => new DOMParser().parseFromString('<body>' + (html || ''), 'text/html').body;
  const clean = (s) => String(s || '').replace(/\u200b/g, '');
  const slug = (s) => (String(s || 'note').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'note');
  F.slug = slug;

  /* ------------------------------------------------------------- html -> md */
  function inline(n) { let s = ''; n.childNodes.forEach((c) => { s += walk(c); }); return s; }
  function wrap(m, x) { return x.trim() ? m + x + m : x; }
  function walk(n) {
    if (n.nodeType === 3) return clean(n.nodeValue);
    if (n.nodeType !== 1) return '';
    const t = n.tagName;
    switch (t) {
      case 'B': case 'STRONG': return wrap('**', inline(n));
      case 'I': case 'EM': return wrap('*', inline(n));
      case 'S': case 'STRIKE': case 'DEL': return wrap('~~', inline(n));
      case 'U': return '<u>' + inline(n) + '</u>';
      case 'CODE': return '`' + inline(n) + '`';
      case 'BR': return '\n';
      case 'HR': return '\n---\n';
      case 'A': return '[' + inline(n) + '](' + (n.getAttribute('href') || '') + ')';
      case 'IMG': return '![' + (n.getAttribute('alt') || 'image') + '](' + (n.getAttribute('src') || '') + ')';
      case 'H1': return '\n# ' + inline(n).trim() + '\n\n';
      case 'H2': return '\n## ' + inline(n).trim() + '\n\n';
      case 'H3': return '\n### ' + inline(n).trim() + '\n\n';
      case 'BLOCKQUOTE': return '\n> ' + inline(n).trim().replace(/\n/g, '\n> ') + '\n\n';
      case 'UL': return '\n' + Array.from(n.children).map((li) => '- ' + inline(li).trim()).join('\n') + '\n\n';
      case 'OL': return '\n' + Array.from(n.children).map((li, i) => (i + 1) + '. ' + inline(li).trim()).join('\n') + '\n\n';
      case 'TABLE': {
        const rows = Array.from(n.rows).map((r) => Array.from(r.cells).map((c) => clean(c.textContent).replace(/\|/g, '\\|').replace(/\s+/g, ' ').trim()));
        if (!rows.length) return '';
        const w = Math.max(...rows.map((r) => r.length));
        const pad = (r) => '| ' + Array.from({ length: w }, (_, i) => r[i] || '').join(' | ') + ' |';
        return '\n' + [pad(rows[0]), '| ' + Array(w).fill('---').join(' | ') + ' |'].concat(rows.slice(1).map(pad)).join('\n') + '\n\n';
      }
      case 'DIV': case 'P':
        if (n.classList.contains('sl-check')) {
          const cb = n.querySelector('input'); const ct = n.querySelector('.sl-ct');
          return '- [' + (cb && cb.hasAttribute('checked') ? 'x' : ' ') + '] ' + clean(ct ? ct.textContent : n.textContent).trim() + '\n';
        }
        return inline(n) + (t === 'P' ? '\n\n' : '\n');
      case 'INPUT': return '';
      default: return inline(n);
    }
  }
  F.htmlToMd = (html) => inline(parseHtml(html)).replace(/\n{3,}/g, '\n\n').trim();

  /* ------------------------------------------------------------- md -> html */
  function mdInline(s) {
    s = SL.esc(s);
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, '<img alt="$1" src="$2">');
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2">$1</a>');
    s = s.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>').replace(/~~([^~]+)~~/g, '<s>$1</s>').replace(/`([^`]+)`/g, '<code>$1</code>');
    return s.replace(/&lt;u&gt;(.*?)&lt;\/u&gt;/g, '<u>$1</u>');
  }
  F.mdToHtml = (md) => {
    const lines = String(md || '').replace(/\r/g, '').split('\n'); const out = []; let i = 0;
    while (i < lines.length) {
      const l = lines[i]; let m;
      if (!l.trim()) { i++; continue; }
      if ((m = l.match(/^(#{1,3})\s+(.*)$/))) { out.push('<h' + Math.min(m[1].length, 2) + '>' + mdInline(m[2]) + '</h' + Math.min(m[1].length, 2) + '>'); i++; continue; }
      if ((m = l.match(/^\s*[-*]\s+\[( |x|X)\]\s?(.*)$/))) { out.push(SL.checkHtml(m[2], m[1] !== ' ')); i++; continue; }
      if (/^\s*[-*]\s+/.test(l)) { const it = []; while (i < lines.length && /^\s*[-*]\s+(?!\[[ xX]\])/.test(lines[i])) { it.push('<li>' + mdInline(lines[i].replace(/^\s*[-*]\s+/, '')) + '</li>'); i++; } out.push('<ul>' + it.join('') + '</ul>'); continue; }
      if (/^\s*\d+\.\s+/.test(l)) { const it = []; while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) { it.push('<li>' + mdInline(lines[i].replace(/^\s*\d+\.\s+/, '')) + '</li>'); i++; } out.push('<ol>' + it.join('') + '</ol>'); continue; }
      if (/^\s*\|.*\|\s*$/.test(l)) {
        const rows = []; while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { if (!/^\s*\|[\s:|-]+\|\s*$/.test(lines[i])) rows.push(lines[i].trim().replace(/^\||\|$/g, '').split(/(?<!\\)\|/).map((c) => c.replace(/\\\|/g, '|').trim())); i++; }
        out.push(tableHtml(rows)); continue;
      }
      if (/^>\s?/.test(l)) { const q = []; while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(mdInline(lines[i].replace(/^>\s?/, ''))); i++; } out.push('<blockquote>' + q.join('<br>') + '</blockquote>'); continue; }
      if (/^(-{3,}|\*{3,})$/.test(l.trim())) { out.push('<hr>'); i++; continue; }
      out.push('<div>' + mdInline(l) + '</div>'); i++;
    }
    return out.join('');
  };
  function tableHtml(rows) {
    const w = Math.max(1, ...rows.map((r) => r.length));
    return '<table class="sl-table"><tbody>' + rows.map((r) => '<tr>' + Array.from({ length: w }, (_, i) => '<td>' + (SL.esc(r[i] || '') || '<br>') + '</td>').join('') + '</tr>').join('') + '</tbody></table><div><br></div>';
  }
  F.textToHtml = (text) => String(text || '').replace(/\r/g, '').split('\n').map((l) => {
    const m = l.match(/^\s*\[( |x|X)\]\s?(.*)$/);
    if (m) return SL.checkHtml(m[2], m[1] !== ' ');
    return '<div>' + (SL.esc(l) || '<br>') + '</div>';
  }).join('');

  /* ----------------------------------------------------------- html -> text */
  F.htmlToText = (html) => {
    const body = parseHtml(html);
    body.querySelectorAll('.sl-check').forEach((c) => {
      const cb = c.querySelector('input'); const ct = c.querySelector('.sl-ct');
      c.replaceWith(parseHtml('<div>' + (cb && cb.hasAttribute('checked') ? '[x] ' : '[ ] ') + SL.esc(clean(ct ? ct.textContent : '')) + '</div>').firstChild);
    });
    body.querySelectorAll('img').forEach((i) => i.replaceWith('[image]'));
    body.querySelectorAll('td,th').forEach((c) => c.append('\t'));
    body.querySelectorAll('div,p,li,h1,h2,h3,tr,blockquote').forEach((e) => e.append('\n'));
    body.querySelectorAll('br').forEach((b) => b.replaceWith('\n'));
    return clean(body.textContent).replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  };

  /* ------------------------------------------------------------------- csv */
  const csvCell = (v) => { v = String(v == null ? '' : v); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  const toCsv = (rows) => '\ufeff' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
  function parseCsv(text) {
    text = String(text || '').replace(/^\ufeff/, '');
    const rows = []; let row = []; let cell = ''; let q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
      else if (c === '"') q = true;
      else if (c === ',') { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; rows.push(row); row = []; }
      else cell += c;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }
  function sheetRows(note) {
    const body = parseHtml(note.html); const tables = Array.from(body.querySelectorAll('table')); const rows = [];
    if (tables.length) { tables.forEach((t, k) => { if (k) rows.push([]); Array.from(t.rows).forEach((r) => rows.push(Array.from(r.cells).map((c) => clean(c.textContent).trim()))); }); }
    else F.htmlToText(note.html).split('\n').forEach((l) => rows.push([l]));
    return rows;
  }

  /* ------------------------------------------------------------------- doc */
  function docBody(note) {
    const body = parseHtml(note.html);
    body.querySelectorAll('.sl-check').forEach((c) => {
      const cb = c.querySelector('input'); const ct = c.querySelector('.sl-ct');
      c.replaceWith(parseHtml('<p>' + (cb && cb.hasAttribute('checked') ? '&#9745; ' : '&#9744; ') + SL.esc(clean(ct ? ct.textContent : '')) + '</p>').firstChild);
    });
    body.querySelectorAll('table').forEach((t) => { t.setAttribute('border', '1'); t.setAttribute('cellpadding', '6'); t.setAttribute('style', 'border-collapse:collapse'); });
    body.querySelectorAll('.sl-img').forEach((s) => s.replaceWith(...Array.from(s.childNodes)));
    return body.innerHTML;
  }
  function docSection(note) {
    return '<h1>' + SL.esc(note.title || 'Untitled') + '</h1><p style="color:#666;font-size:10pt">' + (note.url ? SL.esc(note.url) + ' · ' : '') + 'Edited ' + SL.esc(new Date(note.updatedAt).toLocaleString()) + (note.tags && note.tags.length ? ' · Tags: ' + SL.esc(note.tags.join(', ')) : '') + '</p>' + docBody(note);
  }
  const docWrap = (title, inner) => '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>' + SL.esc(title) + '</title><style>body{font-family:Calibri,Arial,sans-serif;font-size:11pt}h1{font-size:20pt}h2{font-size:15pt}</style></head><body>' + inner + '</body></html>';

  /* ----------------------------------------------------------------- notes */
  function noteCss(n) {
    const rgb = SL.hexToRgb(n.color).join(','); const ink = SL.contrast(n.color);
    return '.skylab-note{background:rgba(' + rgb + ',0.5);color:' + (n.textColor || ink) + ';border:1px solid ' + n.color + ';border-radius:12px;padding:12px;font-family:system-ui,sans-serif}\n.skylab-note-header,.skylab-note-footer{background:' + n.color + ';color:' + ink + '}';
  }
  function plain(n) { return n.locked ? '[This note is locked with a password]' : F.htmlToText(n.html); }
  function exportable(n) { return Object.assign({}, n); }

  F.noteJson = (n) => Object.assign({}, exportable(n), { css: noteCss(n) });

  F.exportNote = (n, fmt) => {
    const base = slug(n.title || 'note');
    if (fmt === 'json') return { name: base + '.skylab.json', mime: 'application/json', data: JSON.stringify({ app: 'Skylab Sticky Note', format: 1, exportedAt: new Date().toISOString(), notes: [F.noteJson(n)] }, null, 2) };
    if (fmt === 'md') {
      const head = '---\ntitle: ' + (n.title || 'Untitled') + '\nurl: ' + (n.url || '') + '\ntags: ' + (n.tags || []).join(', ') + '\ncolor: ' + n.color + '\nupdated: ' + new Date(n.updatedAt).toISOString() + '\n---\n\n';
      return { name: base + '.md', mime: 'text/markdown', data: head + (n.locked ? '_This note is locked with a password._' : F.htmlToMd(n.html)) + '\n' };
    }
    if (fmt === 'doc') return { name: base + '.doc', mime: 'application/msword', data: docWrap(n.title, n.locked ? '<h1>' + SL.esc(n.title || 'Untitled') + '</h1><p>This note is locked with a password.</p>' : docSection(n)) };
    if (fmt === 'sheet') return { name: base + '.sheet', mime: 'text/csv', data: toCsv(n.locked ? [['Locked note']] : sheetRows(n)) };
    return { name: base + '.notepad', mime: 'text/plain', data: notepadBlock(n) };
  };
  function notepadBlock(n) {
    return 'SKYLAB STICKY NOTE\nTitle: ' + (n.title || 'Untitled') + '\nURL: ' + (n.url || '') + '\nTags: ' + (n.tags || []).join(', ') + '\nUpdated: ' + new Date(n.updatedAt).toISOString() + '\n' + '-'.repeat(60) + '\n' + plain(n) + '\n';
  }
  F.exportBundle = (notes, fmt) => {
    const stamp = new Date().toISOString().slice(0, 10);
    if (notes.length === 1) return F.exportNote(notes[0], fmt);
    if (fmt === 'json') return { name: 'skylab-notes-' + stamp + '.json', mime: 'application/json', data: JSON.stringify({ app: 'Skylab Sticky Note', format: 1, exportedAt: new Date().toISOString(), notes: notes.map(F.noteJson) }, null, 2) };
    if (fmt === 'md') return { name: 'skylab-notes-' + stamp + '.md', mime: 'text/markdown', data: notes.map((n) => F.exportNote(n, 'md').data).join('\n\n') };
    if (fmt === 'doc') return { name: 'skylab-notes-' + stamp + '.doc', mime: 'application/msword', data: docWrap('Skylab notes', notes.map((n) => '<div style="page-break-after:always">' + (n.locked ? '<h1>' + SL.esc(n.title || 'Untitled') + '</h1><p>Locked note</p>' : docSection(n)) + '</div>').join('')) };
    if (fmt === 'sheet') return { name: 'skylab-notes-' + stamp + '.sheet', mime: 'text/csv', data: toCsv([['Title', 'URL', 'Tags', 'Created', 'Updated', 'Text']].concat(notes.map((n) => [n.title, n.url, (n.tags || []).join('; '), new Date(n.createdAt).toISOString(), new Date(n.updatedAt).toISOString(), plain(n)]))) };
    return { name: 'skylab-notes-' + stamp + '.notepad', mime: 'text/plain', data: notes.map(notepadBlock).join('\n\n') };
  };
  F.download = (name, mime, data) => {
    const blob = new Blob([data], { type: mime + ';charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; a.style.display = 'none';
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  };

  /* ---------------------------------------------------------------- import */
  F.parseImport = async (file) => {
    const text = await file.text();
    const base = file.name.replace(/\.[^.]+$/, '');
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    const mk = (o) => SL.notes.normalize(Object.assign({ scope: 'none' }, o));
    if (ext === 'json') {
      const d = JSON.parse(text);
      const arr = Array.isArray(d) ? d : Array.isArray(d.notes) ? d.notes : (d && (d.html != null || d.title != null) ? [d] : []);
      if (!arr.length) throw new Error('No notes found in this JSON file');
      return arr.map((o) => { const n = SL.notes.normalize(o); n.id = SL.uid(); n.rev = 1; return n; });
    }
    if (ext === 'md' || ext === 'markdown') {
      let body = text; const meta = {};
      const fm = text.match(/^---\n([\s\S]*?)\n---\n?/);
      if (fm) { body = text.slice(fm[0].length); fm[1].split('\n').forEach((l) => { const i = l.indexOf(':'); if (i > 0) meta[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }); }
      let title = meta.title || base; const h1 = body.match(/^#\s+(.+)$/m);
      if (!meta.title && h1) { title = h1[1]; body = body.replace(h1[0], ''); }
      return [mk({ title, html: F.mdToHtml(body), url: meta.url || '', scope: meta.url ? 'url' : 'none', tags: meta.tags ? meta.tags.split(',').map((t) => t.trim()) : [], color: meta.color })];
    }
    if (ext === 'doc' || ext === 'html' || ext === 'htm') {
      const doc = new DOMParser().parseFromString(text, 'text/html');
      let title = (doc.title || '').trim(); const h1 = doc.body.querySelector('h1');
      if (!title && h1) title = h1.textContent.trim();
      if (h1 && h1.textContent.trim() === title) h1.remove();
      return [mk({ title: title || base, html: doc.body.innerHTML })];
    }
    if (ext === 'sheet' || ext === 'csv') {
      const rows = parseCsv(text).filter((r) => r.length);
      if (rows[0] && rows[0][0] === 'Title' && rows[0][1] === 'URL' && rows[0][5] === 'Text') {
        return rows.slice(1).map((r) => mk({ title: r[0], url: r[1], scope: r[1] ? 'url' : 'none', tags: (r[2] || '').split(';'), html: F.textToHtml(r[5] || ''), createdAt: Date.parse(r[3]) || Date.now(), updatedAt: Date.parse(r[4]) || Date.now() }));
      }
      return [mk({ title: base, html: tableHtml(rows) })];
    }
    // .notepad / .txt
    const chunks = text.split(/^SKYLAB STICKY NOTE\r?$/m).map((c) => c.trim()).filter(Boolean);
    if (/^SKYLAB STICKY NOTE/m.test(text) && chunks.length) {
      return chunks.map((c) => {
        const idx = c.search(/^-{20,}$/m); const head = idx > -1 ? c.slice(0, idx) : ''; const body = idx > -1 ? c.slice(idx).replace(/^-+\r?\n?/, '') : c;
        const meta = {}; head.split('\n').forEach((l) => { const i = l.indexOf(':'); if (i > 0) meta[l.slice(0, i).trim().toLowerCase()] = l.slice(i + 1).trim(); });
        return mk({ title: meta.title || base, url: meta.url || '', scope: meta.url ? 'url' : 'none', tags: (meta.tags || '').split(','), html: F.textToHtml(body.trim()) });
      });
    }
    return [mk({ title: base, html: F.textToHtml(text) })];
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
