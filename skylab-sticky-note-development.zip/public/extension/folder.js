/* Skylab Sticky Note – optional local folder mirror (File System Access API) */
(function (g) {
  'use strict';
  const SL = g.SL; const F = (SL.folder = {});
  F.supported = typeof g.showDirectoryPicker === 'function';
  const DB = 'skylab-fs'; const ST = 'handles';

  function openDb() {
    return new Promise((res, rej) => { const r = indexedDB.open(DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(ST); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  }
  async function idb(mode, fn) {
    const d = await openDb();
    return new Promise((res, rej) => { const tx = d.transaction(ST, mode); const rq = fn(tx.objectStore(ST)); tx.oncomplete = () => res(rq && rq.result); tx.onerror = () => rej(tx.error); });
  }
  F.getHandle = () => idb('readonly', (s) => s.get('dir'));
  F.setHandle = (h) => idb('readwrite', (s) => s.put(h, 'dir'));
  F.forget = async () => { await idb('readwrite', (s) => s.delete('dir')); await SL.settings.set({ folderEnabled: false }); };

  F.pick = async () => {
    const h = await g.showDirectoryPicker({ mode: 'readwrite', id: 'skylab-notes' });
    await F.setHandle(h); await SL.settings.set({ folderEnabled: true, folderSyncedAt: 0 });
    return h;
  };
  F.permission = async (h, request) => {
    const o = { mode: 'readwrite' };
    if ((await h.queryPermission(o)) === 'granted') return true;
    return request ? (await h.requestPermission(o)) === 'granted' : false;
  };
  F.status = async () => {
    if (!F.supported) return { state: 'unsupported' };
    const h = await F.getHandle(); if (!h) return { state: 'none' };
    return { state: (await F.permission(h, false)) ? 'ready' : 'needs-permission', name: h.name };
  };
  const fileName = (n) => SL.fmt.slug(n.title || 'untitled') + '__' + n.id + '.md';
  async function listFiles(dir) {
    const map = new Map();
    for await (const [name] of dir.entries()) { const m = name.match(/__([a-z0-9]+)\.md$/); if (m) map.set(m[1], name); }
    return map;
  }
  async function write(dir, n, files) {
    const name = fileName(n); const old = files.get(n.id);
    const fh = await dir.getFileHandle(name, { create: true }); const w = await fh.createWritable();
    await w.write(SL.fmt.exportNote(n, 'md').data); await w.close();
    if (old && old !== name) { try { await dir.removeEntry(old); } catch (e) { /* ignore */ } }
    files.set(n.id, name);
  }
  /* returns { written, skipped } */
  F.syncAll = async (opts) => {
    opts = opts || {}; const h = await F.getHandle(); if (!h) throw new Error('No folder selected');
    if (!(await F.permission(h, !!opts.request))) throw new Error('Permission to the folder is needed — click “Reconnect”.');
    const files = await listFiles(h); const settings = await SL.settings.get(); const since = opts.all ? 0 : settings.folderSyncedAt || 0;
    let written = 0; let skipped = 0;
    for (const n of await SL.notes.all()) {
      if (n.locked) { skipped++; continue; }
      if (n.updatedAt > since || !files.has(n.id)) { await write(h, n, files); written++; }
    }
    await SL.settings.set({ folderSyncedAt: Date.now() });
    return { written, skipped };
  };
  F.syncChanged = () => F.syncAll({});
  F.writeOne = async (n) => {
    const h = await F.getHandle(); if (!h || n.locked || !(await F.permission(h, false))) return;
    await write(h, n, await listFiles(h));
  };
  F.removeOne = async (id) => {
    const h = await F.getHandle(); if (!h || !(await F.permission(h, false))) return;
    const files = await listFiles(h); if (files.has(id)) { try { await h.removeEntry(files.get(id)); } catch (e) { /* ignore */ } }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
