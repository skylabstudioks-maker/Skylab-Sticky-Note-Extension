/* Skylab Sticky Note – UI kit + NoteWindow (shared by content script and dashboard) */
(function (g) {
  'use strict';
  const SL = g.SL;

  /* ------------------------------------------------------------------ icons */
  const PATHS = {
    chevronDown: '<polyline points="6 9 12 15 18 9"/>',
    pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',
    more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    check: '<path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
    pencil: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    table: '<path d="M12 3v18"/><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    palette: '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
    eraser: '<path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"/><path d="M22 21H7"/><path d="m5 11 9 9"/>',
    save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    archive: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
    settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/>',
    home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    undo: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/>',
    crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
    grid: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
    list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
    folder: '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
    note: '<path d="M15.5 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3Z"/><path d="M15 3v6h6"/>'
  };
  SL.icon = (name, size) => '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (PATHS[name] || '') + '</svg>';

  function h(tag, props) {
    const e = document.createElement(tag);
    Object.keys(props || {}).forEach((k) => {
      const v = props[k];
      if (v == null || v === false) return;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k === 'html') e.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    });
    for (let i = 2; i < arguments.length; i++) {
      [].concat(arguments[i]).forEach((k) => { if (k == null || k === false) return; e.append(k.nodeType ? k : document.createTextNode(k)); });
    }
    return e;
  }
  SL.h = h;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* --------------------------------------------------------------------- UI */
  const UI = (SL.ui = { layer: null, openNoteHandler: null });
  UI.setLayer = (el) => { UI.layer = el; };
  const layerEl = () => UI.layer || document.body;

  UI.modal = function (opts) {
    return new Promise((resolve) => {
      const back = h('div', { class: 'sl-modal-back' });
      const box = h('div', { class: 'sl-modal', role: 'dialog', 'aria-modal': 'true', tabindex: '-1', style: { maxWidth: (opts.width || 420) + 'px' } });
      let done = false;
      const ctl = {
        box,
        close(val) {
          if (done) return; done = true;
          back.classList.add('out'); setTimeout(() => back.remove(), 150); resolve(val);
        }
      };
      box.append(h('div', { class: 'sl-modal-h' }, h('h3', { text: opts.title || '' }), opts.dismissable === false ? null : h('button', { class: 'sl-ibtn', type: 'button', html: SL.icon('x'), 'aria-label': 'Close', onclick: () => ctl.close(undefined) })));
      const body = h('div', { class: 'sl-modal-b' });
      const content = typeof opts.body === 'function' ? opts.body(ctl) : opts.body;
      if (typeof content === 'string') body.textContent = content; else if (content) body.append(content);
      box.append(body);
      if (opts.buttons && opts.buttons.length) {
        box.append(h('div', { class: 'sl-modal-f' }, opts.buttons.map((b) => h('button', {
          class: 'sl-btn ' + (b.kind || ''), type: 'button', text: b.label,
          onclick: async () => {
            if (b.onClick) { const r = await b.onClick(ctl); if (r === false) return; }
            ctl.close(b.value);
          }
        }))));
      }
      back.append(box);
      back.addEventListener('mousedown', (e) => { if (e.target === back && opts.dismissable !== false) ctl.close(undefined); });
      back.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && opts.dismissable !== false) { e.stopPropagation(); ctl.close(undefined); }
        else if (e.key === 'Enter' && e.target.tagName === 'INPUT' && opts.enterButton != null) { e.preventDefault(); const bs = box.querySelectorAll('.sl-modal-f .sl-btn'); if (bs[opts.enterButton]) bs[opts.enterButton].click(); }
      });
      layerEl().append(back);
      const first = box.querySelector('[data-autofocus]') || box.querySelector('input,textarea,select');
      setTimeout(() => (first || box).focus(), 30);
      if (opts.onOpen) opts.onOpen(ctl);
    });
  };
  UI.confirm = (message, o) => {
    o = o || {};
    return UI.modal({ title: o.title || 'Please confirm', width: 400, body: h('p', { class: 'sl-p', text: message }), buttons: [{ label: o.cancelLabel || 'Cancel', kind: 'ghost', value: false }, { label: o.okLabel || 'OK', kind: o.danger ? 'danger' : 'primary', value: true }] }).then((v) => !!v);
  };
  UI.alert = (message, title) => UI.modal({ title: title || 'Notice', width: 400, body: h('p', { class: 'sl-p', text: message }), buttons: [{ label: 'OK', kind: 'primary', value: true }] });
  UI.prompt = (o) => {
    const input = o.multiline ? h('textarea', { class: 'sl-input', rows: '5', placeholder: o.placeholder || '', 'data-autofocus': '' }) : h('input', { class: 'sl-input', type: o.type || 'text', placeholder: o.placeholder || '', 'data-autofocus': '' });
    input.value = o.value || '';
    return UI.modal({
      title: o.title || 'Enter value', width: 420, enterButton: o.multiline ? null : 1,
      body: h('div', null, o.label ? h('label', { class: 'sl-label', text: o.label }) : null, input, o.hint ? h('p', { class: 'sl-hint', text: o.hint }) : null),
      buttons: [{ label: 'Cancel', kind: 'ghost', value: null }, { label: o.okLabel || 'OK', kind: 'primary', onClick: (c) => { c.result = input.value; }, value: '__ok__' }]
    }).then((v) => (v === '__ok__' ? input.value : null));
  };
  let toastTimer = null;
  UI.toast = (msg, o) => {
    const l = layerEl(); l.querySelectorAll(':scope > .sl-toast').forEach((t) => t.remove());
    const t = h('div', { class: 'sl-toast', role: 'status' }, h('span', { text: msg }));
    if (o && o.action) t.append(h('button', { type: 'button', class: 'sl-toast-a', text: o.action.label, onclick: () => { o.action.fn(); t.remove(); } }));
    l.append(t); clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 200); }, (o && o.ms) || 2600);
  };

  /* images ------------------------------------------------------------- */
  const IMG_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/bmp'];
  UI.fileToDataUrl = (file, maxDim) => new Promise((resolve, reject) => {
    if (!IMG_TYPES.includes(file.type)) { reject(new Error('Unsupported image type')); return; }
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('Could not read the image'));
    fr.onload = () => {
      const src = fr.result;
      if (file.type === 'image/gif') { resolve(src); return; }
      const img = new Image();
      img.onerror = () => reject(new Error('Could not decode the image'));
      img.onload = () => {
        const sc = Math.min(1, maxDim / Math.max(img.width, img.height));
        if (sc === 1 && file.size < 1.5e6) { resolve(src); return; }
        const c = document.createElement('canvas'); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.88));
      };
      img.src = src;
    };
    fr.readAsDataURL(file);
  });

  /* Drawing board + crop editor ---------------------------------------- */
  UI.canvasEditor = function (o) {
    o = o || {};
    return new Promise((resolve) => {
      const cv = h('canvas', { class: 'sl-cv' });
      const ctx = cv.getContext('2d', { willReadFrequently: true });
      const sel = h('div', { class: 'sl-crop-sel' }); sel.style.display = 'none';
      const wrap = h('div', { class: 'sl-cv-wrap' }, cv, sel);
      let tool = o.mode === 'crop' ? 'crop' : 'pen'; let color = '#e03131'; let size = 4; let drawing = false; let last = null; let start = null; let crop = null;
      const undo = [];
      const snap = () => { undo.push(ctx.getImageData(0, 0, cv.width, cv.height)); if (undo.length > 30) undo.shift(); };
      const whiteFill = () => { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, cv.width, cv.height); };
      const wIn = h('input', { class: 'sl-input sm', type: 'number', min: '40', max: '3000' });
      const hIn = h('input', { class: 'sl-input sm', type: 'number', min: '40', max: '3000' });
      const stretch = h('input', { type: 'checkbox' });
      const syncSize = () => { wIn.value = cv.width; hIn.value = cv.height; };
      function init(w, hh, img) {
        cv.width = w; cv.height = hh; whiteFill(); if (img) ctx.drawImage(img, 0, 0, w, hh); syncSize();
      }
      if (o.src) {
        const img = new Image();
        img.onload = () => { const sc = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight)); init(Math.round(img.naturalWidth * sc), Math.round(img.naturalHeight * sc), img); };
        img.src = o.src;
      } else init(o.width || 640, o.height || 380);

      const pt = (e) => { const r = cv.getBoundingClientRect(); return { x: SL.clamp((e.clientX - r.left) * cv.width / r.width, 0, cv.width), y: SL.clamp((e.clientY - r.top) * cv.height / r.height, 0, cv.height) }; };
      function showSel() {
        if (!crop) { sel.style.display = 'none'; return; }
        const r = cv.getBoundingClientRect(); const wr = wrap.getBoundingClientRect(); const k = r.width / cv.width;
        Object.assign(sel.style, { display: 'block', left: (r.left - wr.left + wrap.scrollLeft + crop.x * k) + 'px', top: (r.top - wr.top + wrap.scrollTop + crop.y * k) + 'px', width: crop.w * k + 'px', height: crop.h * k + 'px' });
      }
      cv.addEventListener('pointerdown', (e) => {
        e.preventDefault(); cv.setPointerCapture(e.pointerId); const p = pt(e);
        if (tool === 'crop') { start = p; crop = { x: p.x, y: p.y, w: 0, h: 0 }; showSel(); drawing = true; return; }
        snap(); drawing = true; last = p;
        ctx.fillStyle = tool === 'eraser' ? '#ffffff' : color; ctx.beginPath(); ctx.arc(p.x, p.y, (tool === 'eraser' ? size * 3 : size) / 2, 0, Math.PI * 2); ctx.fill();
      });
      cv.addEventListener('pointermove', (e) => {
        if (!drawing) return; const p = pt(e);
        if (tool === 'crop') { crop = { x: Math.min(start.x, p.x), y: Math.min(start.y, p.y), w: Math.abs(p.x - start.x), h: Math.abs(p.y - start.y) }; showSel(); return; }
        ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color; ctx.lineWidth = tool === 'eraser' ? size * 3 : size; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke(); last = p;
      });
      const up = () => { drawing = false; };
      cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);

      const toolBtns = {};
      const mkTool = (id, label, icon) => { const b = h('button', { type: 'button', class: 'sl-chip' + (tool === id ? ' on' : ''), html: SL.icon(icon, 15) + '<span>' + label + '</span>', onclick: () => { tool = id; Object.keys(toolBtns).forEach((k) => toolBtns[k].classList.toggle('on', k === id)); cv.style.cursor = id === 'crop' ? 'crosshair' : 'crosshair'; applyBtn.style.display = id === 'crop' ? '' : 'none'; if (id !== 'crop') { crop = null; showSel(); } } }); toolBtns[id] = b; return b; };
      const colorIn = h('input', { type: 'color', value: color, class: 'sl-colorin', title: 'Pen color', oninput: (e) => { color = e.target.value; if (tool === 'eraser') toolBtns.pen.click(); } });
      const sizeIn = h('input', { type: 'range', min: '1', max: '40', value: String(size), title: 'Brush size', oninput: (e) => { size = +e.target.value; } });
      const applyBtn = h('button', {
        type: 'button', class: 'sl-btn primary sm', text: 'Apply crop', onclick: () => {
          if (!crop || crop.w < 4 || crop.h < 4) { UI.toast('Drag on the canvas to select the area to keep'); return; }
          snap(); const x = Math.round(crop.x), y = Math.round(crop.y), w = Math.round(crop.w), hh = Math.round(crop.h);
          const d = ctx.getImageData(x, y, w, hh); cv.width = w; cv.height = hh; ctx.putImageData(d, 0, 0); crop = null; showSel(); syncSize();
        }
      });
      applyBtn.style.display = tool === 'crop' ? '' : 'none';
      const resizeBtn = h('button', {
        type: 'button', class: 'sl-btn ghost sm', text: 'Resize', onclick: () => {
          const w = SL.clamp(parseInt(wIn.value, 10) || cv.width, 40, 3000); const hh = SL.clamp(parseInt(hIn.value, 10) || cv.height, 40, 3000);
          snap(); const tmp = document.createElement('canvas'); tmp.width = cv.width; tmp.height = cv.height; tmp.getContext('2d').drawImage(cv, 0, 0);
          cv.width = w; cv.height = hh; whiteFill(); if (stretch.checked) ctx.drawImage(tmp, 0, 0, w, hh); else ctx.drawImage(tmp, 0, 0); crop = null; showSel(); syncSize();
        }
      });
      const bar1 = h('div', { class: 'sl-cv-bar' }, mkTool('pen', 'Pen', 'pencil'), mkTool('eraser', 'Eraser', 'eraser'), mkTool('crop', 'Crop', 'crop'), colorIn, sizeIn,
        h('button', { type: 'button', class: 'sl-chip', html: SL.icon('undo', 15) + '<span>Undo</span>', onclick: () => { const d = undo.pop(); if (!d) return; cv.width = d.width; cv.height = d.height; ctx.putImageData(d, 0, 0); syncSize(); crop = null; showSel(); } }),
        h('button', { type: 'button', class: 'sl-chip', html: SL.icon('trash', 15) + '<span>Clear</span>', onclick: () => { snap(); whiteFill(); } }), applyBtn);
      const bar2 = h('div', { class: 'sl-cv-bar' }, h('span', { class: 'sl-hint', text: 'Board size' }), wIn, h('span', { text: '×' }), hIn, h('label', { class: 'sl-inline' }, stretch, ' Stretch drawing'), resizeBtn);
      UI.modal({
        title: o.title || (o.mode === 'crop' ? 'Crop image' : o.src ? 'Edit image' : 'Drawing board'), width: 760, dismissable: false,
        body: h('div', null, bar1, wrap, bar2),
        buttons: [{ label: 'Cancel', kind: 'ghost', value: null }, { label: o.src ? 'Save image' : 'Insert drawing', kind: 'primary', value: '__ok__' }]
      }).then((v) => {
        if (v !== '__ok__') { resolve(null); return; }
        resolve(cv.toDataURL(o.src && /^data:image\/jpe?g/.test(o.src) ? 'image/jpeg' : 'image/png', 0.92));
      });
    });
  };

  /* reminder popup ------------------------------------------------------ */
  UI.reminderPopup = (note) => {
    const l = layerEl(); const id = 'rem-' + note.id;
    l.querySelectorAll('.sl-remind[data-id="' + note.id + '"]').forEach((e) => e.remove());
    const card = h('div', { class: 'sl-remind', 'data-id': note.id, role: 'alertdialog' },
      h('div', { class: 'sl-remind-h' }, h('span', { class: 'sl-remind-ic', html: SL.icon('bell', 18) }), h('b', { text: 'Reminder' })),
      h('div', { class: 'sl-remind-t', text: note.title || 'Untitled note' }),
      h('div', { class: 'sl-remind-m', text: note.message || '' }),
      h('div', { class: 'sl-remind-f' },
        h('button', { class: 'sl-btn primary sm', type: 'button', text: 'Open note', onclick: () => { card.remove(); if (UI.openNoteHandler) UI.openNoteHandler(note.id); } }),
        h('button', {
          class: 'sl-btn ghost sm', type: 'button', text: 'Snooze 10 min', onclick: async () => {
            const n = await SL.notes.get(note.id); if (n && n.reminder) { n.reminder.at = Date.now() + 10 * 60000; n.reminder.fired = false; n.rev = (n.rev || 0) + 1; await SL.notes.save(n); }
            card.remove(); UI.toast('Snoozed for 10 minutes');
          }
        }),
        h('button', { class: 'sl-btn ghost sm', type: 'button', text: 'Dismiss', onclick: () => card.remove() })));
    l.append(card); void id;
  };
  if (SL.hasRuntime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'reminder' && m.note) UI.reminderPopup(m.note); });
  }

  /* ------------------------------------------------------------- NoteWindow */
  const FONTS = [['Sans-serif', '"Segoe UI",system-ui,-apple-system,Roboto,Helvetica,Arial,sans-serif'], ['Serif', 'Georgia,"Times New Roman",serif'], ['Monospace', 'ui-monospace,SFMono-Regular,Consolas,"Courier New",monospace'], ['Arial', 'Arial,Helvetica,sans-serif'], ['Verdana', 'Verdana,Geneva,sans-serif'], ['Trebuchet', '"Trebuchet MS",sans-serif'], ['Georgia', 'Georgia,serif'], ['Times', '"Times New Roman",Times,serif'], ['Courier', '"Courier New",monospace'], ['Comic', '"Comic Sans MS","Comic Neue",cursive'], ['Handwriting', '"Segoe Print","Bradley Hand","Chalkboard SE",cursive']];
  const SIZES = [10, 12, 13, 14, 16, 18, 20, 24, 28, 32, 40, 48];
  const FONT_MAP = { 1: 10, 2: 13, 3: 16, 4: 18, 5: 24, 6: 32, 7: 48 };
  const MINW = 280; const MINH = 200;
  let zTop = 10;
  const pad2 = (n) => String(n).padStart(2, '0');
  const toLocalInput = (ts) => { const d = new Date(ts); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };

  class NoteWindow {
    constructor(note, opts) {
      this.note = note; this.opts = Object.assign({ mode: 'float' }, opts || {});
      this.embedded = this.opts.mode === 'embedded';
      this.saveTimer = null; this.dirty = false; this.sessionPw = null; this.unlocked = false; this.range = null;
      this.pop = null; this.popAnchor = null; this.popOff = null; this.selImg = null; this.marks = []; this.cur = -1; this.pendingSize = null; this.destroyed = false;
      this.build();
      if (this.opts.parent) this.opts.parent.append(this.root);
      this.selListener = () => this.saveRange();
      document.addEventListener('selectionchange', this.selListener);
      this.refresh();
    }

    /* ---- construction ---- */
    ibtn(act, title, icon) {
      return h('button', { class: 'sl-ibtn', type: 'button', 'data-act': act, title, 'aria-label': title, html: SL.icon(icon, 16) });
    }
    tbtn(content, title, fn, o) {
      o = o || {};
      const b = h('button', { class: 'sl-tbtn ' + (o.cls || ''), type: 'button', title, 'aria-label': title });
      if (o.icon) b.innerHTML = SL.icon(o.icon, 16) + (o.label ? '<span>' + o.label + '</span>' : ''); else b.innerHTML = content;
      b.addEventListener('mousedown', (e) => e.preventDefault());
      b.addEventListener('click', (e) => { e.preventDefault(); fn(e, b); });
      return b;
    }
    build() {
      const self = this;
      this.titleEl = h('input', { class: 'sl-title', placeholder: 'Title', maxlength: '200', 'aria-label': 'Note title', autocomplete: 'off' });
      this.btnCollapse = this.ibtn('collapse', 'Hide / show toolbar', 'chevronDown');
      this.btnPin = this.ibtn('pin', 'Pin on top', 'pin');
      this.btnColor = this.ibtn('color', 'Note & text color', 'palette');
      this.btnMore = this.ibtn('more', 'More options', 'more');
      this.btnClose = this.ibtn('close', this.embedded ? 'Close editor' : 'Close note (keeps it saved)', 'x');
      this.head = h('div', { class: 'sl-head' }, this.titleEl, this.btnCollapse, this.btnPin, this.btnColor, this.btnMore, this.btnClose);

      this.urlBtn = h('button', { class: 'sl-url', type: 'button', title: 'Open the page this note is bound to' });
      this.bellEl = h('button', { class: 'sl-bell', type: 'button', html: SL.icon('bell', 13), title: 'Reminder', onclick: () => this.openReminder() });
      this.labelBtn = h('button', { class: 'sl-label-btn', type: 'button', title: 'Labels / tags' });
      this.editedEl = h('span', { class: 'sl-edited' });
      this.saveBtn = h('button', { class: 'sl-savebtn', type: 'button', html: SL.icon('save', 13) + '<span>Save</span>', onclick: () => this.commit({ force: true }) });
      this.sub = h('div', { class: 'sl-sub' }, this.urlBtn, h('span', { class: 'sl-grow' }), this.bellEl, this.saveBtn, this.labelBtn, this.editedEl);

      this.ed = h('div', { class: 'sl-editor empty', contenteditable: 'true', spellcheck: 'true', role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'Note content', 'data-ph': 'Write something…' });
      this.findIn = h('input', { class: 'sl-input sm', placeholder: 'Find', oninput: () => this.runFind() });
      this.repIn = h('input', { class: 'sl-input sm', placeholder: 'Replace with' });
      this.caseCb = h('input', { type: 'checkbox', onchange: () => this.runFind() });
      this.cnt = h('span', { class: 'sl-cnt' });
      this.findBar = h('div', { class: 'sl-find' },
        h('div', { class: 'sl-find-r' }, this.findIn, h('button', { class: 'sl-mini', type: 'button', title: 'Previous', text: '‹', onclick: () => this.stepFind(-1) }), h('button', { class: 'sl-mini', type: 'button', title: 'Next', text: '›', onclick: () => this.stepFind(1) }), this.cnt, h('button', { class: 'sl-mini', type: 'button', title: 'Close', html: SL.icon('x', 13), onclick: () => this.closeFind() })),
        h('div', { class: 'sl-find-r' }, this.repIn, h('button', { class: 'sl-mini wide', type: 'button', text: 'Replace', onclick: () => this.replaceOne() }), h('button', { class: 'sl-mini wide', type: 'button', text: 'All', onclick: () => this.replaceAll() }), h('label', { class: 'sl-inline' }, this.caseCb, ' Aa')));
      this.findBar.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.stepFind(e.shiftKey ? -1 : 1); } if (e.key === 'Escape') { e.stopPropagation(); this.closeFind(); } });

      this.ctxBar = h('div', { class: 'sl-ctx' });
      this.lockEl = this.buildLock();
      this.body = h('div', { class: 'sl-body' }, this.findBar, this.ed, this.ctxBar, this.lockEl);

      /* single-row footer toolbar */
      this.fontBtn = this.tbtn('Font', 'Font family', (e, b) => this.openFontMenu(b), { cls: 'dd' });
      this.sizeBtn = this.tbtn('14', 'Font size', (e, b) => this.openSizeMenu(b), { cls: 'dd narrow' });
      this.fmt = {
        h1: this.tbtn('<b>H1</b>', 'Heading 1', () => this.toggleHeading('H1')),
        h2: this.tbtn('<b>H2</b>', 'Heading 2', () => this.toggleHeading('H2')),
        bold: this.tbtn('<b>B</b>', 'Bold (Ctrl+B)', () => this.exec('bold')),
        italic: this.tbtn('<i style="font-family:serif">I</i>', 'Italic (Ctrl+I)', () => this.exec('italic')),
        underline: this.tbtn('<u>U</u>', 'Underline (Ctrl+U)', () => this.exec('underline')),
        strike: this.tbtn('<s>S</s>', 'Strikethrough', () => this.exec('strikeThrough'))
      };
      this.tools = h('div', { class: 'sl-tools', role: 'toolbar', 'aria-label': 'Formatting and tools' },
        this.fontBtn, this.sizeBtn, this.fmt.h1, this.fmt.h2, this.fmt.bold, this.fmt.italic, this.fmt.underline, this.fmt.strike,
        this.tbtn('', 'Clear formatting', () => this.clearFormat(), { icon: 'eraser' }),
        h('span', { class: 'sl-div' }),
        this.tbtn('', 'Checklist', () => this.addChecklist(), { icon: 'check' }),
        this.tbtn('', 'Drawing board', () => this.newDrawing(), { icon: 'pencil' }),
        this.tbtn('', 'Attach image', () => this.pickImage(), { icon: 'image' }),
        this.tbtn('', 'Insert table', () => this.insertTableDialog(), { icon: 'table' }),
        this.tbtn('', 'Reminder', () => this.openReminder(), { icon: 'bell' }));
      this.tools.addEventListener('wheel', (e) => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { this.tools.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
      this.foot = h('div', { class: 'sl-foot' }, this.tools);
      this.fileIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp,image/bmp', multiple: true, style: { display: 'none' }, onchange: async (e) => { for (const f of Array.from(e.target.files)) await this.insertImageFile(f); e.target.value = ''; } });

      this.root = h('div', { class: 'sl-note', 'data-mode': this.opts.mode, role: 'group', 'aria-label': 'Sticky note' }, this.head, this.sub, this.body, this.foot, this.fileIn);
      if (!this.embedded) ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'].forEach((d) => this.root.append(h('div', { class: 'sl-rz sl-rz-' + d, 'data-dir': d })));

      /* header wiring */
      this.btnClose.addEventListener('click', () => this.close());
      this.btnCollapse.addEventListener('click', () => { this.note.toolbarHidden = !this.note.toolbarHidden; this.applyFlags(); this.commit({ touch: false }); });
      this.btnPin.addEventListener('click', () => { this.note.pinned = !this.note.pinned; this.applyFlags(); this.bump(); this.commit({ touch: false }); if (this.opts.onPinChange) this.opts.onPinChange(this); });
      this.btnColor.addEventListener('click', () => this.openColorMenu(this.btnColor));
      this.btnMore.addEventListener('click', () => this.openMoreMenu(this.btnMore));
      this.labelBtn.addEventListener('click', () => this.openLabelMenu(this.labelBtn));
      this.urlBtn.addEventListener('click', () => { if (this.note.url) window.open(this.note.url, '_blank', 'noopener'); else this.changeUrl(); });
      this.titleEl.addEventListener('input', () => this.onInput());
      this.titleEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.ed.focus(); } });
      this.root.addEventListener('pointerdown', () => this.bump(), true);
      this.root.addEventListener('keydown', (e) => this.onKey(e));

      /* editor wiring */
      this.ed.addEventListener('input', () => { this.fixFonts(); this.onInput(); });
      ['keyup', 'mouseup', 'focus'].forEach((ev) => this.ed.addEventListener(ev, () => this.saveRange()));
      this.ed.addEventListener('keydown', (e) => this.onEditorKey(e));
      this.ed.addEventListener('click', (e) => this.onEditorClick(e));
      this.ed.addEventListener('change', (e) => { const t = e.target; if (t && t.tagName === 'INPUT' && t.type === 'checkbox') { if (t.checked) t.setAttribute('checked', ''); else t.removeAttribute('checked'); const line = t.closest('.sl-check'); if (line) line.classList.toggle('sl-done', t.checked); this.onInput(); } });
      this.ed.addEventListener('paste', (e) => this.onPaste(e));
      this.ed.addEventListener('drop', (e) => { const files = Array.from((e.dataTransfer && e.dataTransfer.files) || []).filter((f) => f.type.startsWith('image/')); if (files.length) { e.preventDefault(); files.forEach((f) => this.insertImageFile(f)); } });
      this.ed.addEventListener('pointerup', () => { if (this.selImg) this.syncImgSize(); });
      if (!this.embedded) { this.initDrag(); this.initResize(); }
      void self;
    }

    buildLock() {
      this.lockMsg = h('div', { class: 'sl-lock-err' });
      this.lockPw = h('input', { class: 'sl-input', type: 'password', placeholder: 'Password', autocomplete: 'off', 'aria-label': 'Password' });
      const go = () => this.unlock();
      this.lockPw.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      return h('div', { class: 'sl-lock' },
        h('div', { class: 'sl-lock-card' }, h('div', { class: 'sl-lock-ic', html: SL.icon('lock', 26) }), h('b', { text: 'This note is locked' }),
          h('p', { text: 'Enter the password to read and edit it. Notes are encrypted with AES-256 on this device.' }),
          this.lockPw, h('button', { class: 'sl-btn primary', type: 'button', text: 'Unlock', onclick: go }), this.lockMsg,
          h('small', { text: 'Forgotten passwords cannot be recovered.' })));
    }

    /* ---- rendering ---- */
    refresh() {
      const n = this.note;
      this.titleEl.value = n.title || '';
      this.applyStyle(); this.applyFlags();
      if (n.locked && !this.unlocked) { this.showLock(); } else { this.hideLock(); if (!(this.opts.keepEditor)) this.setEditorHtml(n.html); }
      this.updateMeta(); this.place();
    }
    applyStyle() {
      const n = this.note; const rgb = SL.hexToRgb(n.color); const ink = SL.contrast(n.color);
      const st = this.root.style;
      st.setProperty('--note', n.color); st.setProperty('--note-rgb', rgb.join(',')); st.setProperty('--ink', ink); st.setProperty('--body-ink', n.textColor || ink);
    }
    applyFlags() {
      const n = this.note;
      this.root.classList.toggle('sl-tb-hidden', !!n.toolbarHidden);
      this.root.classList.toggle('sl-pinned', !!n.pinned);
      this.btnPin.classList.toggle('on', !!n.pinned);
      this.btnPin.title = n.pinned ? 'Unpin' : 'Pin on top';
      this.btnCollapse.title = n.toolbarHidden ? 'Show toolbar' : 'Hide toolbar';
      this.btnCollapse.setAttribute('aria-expanded', String(!n.toolbarHidden));
    }
    setEditorHtml(html) {
      this.ed.innerHTML = SL.sanitize(html || '');
      this.ed.querySelectorAll('.sl-img').forEach((s) => { s.contentEditable = 'false'; });
      this.toggleEmpty();
    }
    toggleEmpty() { this.ed.classList.toggle('empty', !this.ed.textContent.replace(/\u200b/g, '') && !this.ed.querySelector('img,table,.sl-check')); }
    updateMeta() {
      const n = this.note;
      this.urlBtn.innerHTML = SL.icon('link', 12) + '<span></span>';
      this.urlBtn.lastChild.textContent = n.url ? SL.shortUrl(n.url) : 'No page linked';
      this.urlBtn.title = n.url ? n.url + (n.pageTitle ? '\n' + n.pageTitle : '') + '\n(click to open)' : 'Click to set a source page';
      const t = n.tags || [];
      this.labelBtn.innerHTML = SL.icon('tag', 13) + '<span></span>';
      this.labelBtn.lastChild.textContent = t.length ? t[0] + (t.length > 1 ? ' +' + (t.length - 1) : '') : 'Label';
      this.labelBtn.classList.toggle('has', t.length > 0);
      this.editedEl.textContent = SL.fmtEdited(n.updatedAt || Date.now());
      this.editedEl.title = 'Last edited ' + SL.fmtDateTime(n.updatedAt || Date.now()) + '\nCreated ' + SL.fmtDateTime(n.createdAt || Date.now());
      const r = n.reminder; const pending = r && r.at && !r.fired;
      this.bellEl.style.display = r && r.at ? '' : 'none';
      this.bellEl.classList.toggle('done', !pending);
      this.bellEl.title = r && r.at ? 'Reminder: ' + SL.fmtDateTime(r.at) + (r.repeat && r.repeat !== 'none' ? ' (repeats ' + r.repeat + ')' : '') : '';
      const auto = this.opts.autoSave ? this.opts.autoSave() : true;
      this.saveBtn.style.display = this.dirty && !auto ? '' : 'none';
    }
    place() {
      if (this.embedded) return;
      const n = this.note; const st = this.root.style;
      const w = Math.min(n.w, window.innerWidth - 12); const hh = Math.min(n.h, window.innerHeight - 12);
      const x = SL.clamp(n.x, -w + 90, window.innerWidth - 90); const y = SL.clamp(n.y, 0, window.innerHeight - 44);
      st.left = x + 'px'; st.top = y + 'px'; st.width = w + 'px'; st.height = hh + 'px';
    }
    bump() { if (this.embedded) return; this.root.style.zIndex = (++zTop) + (this.note.pinned ? 100000 : 0); }

    /* ---- selection helpers ---- */
    sel() { const r = this.root.getRootNode(); return r && r.getSelection ? r.getSelection() : document.getSelection(); }
    saveRange() {
      if (this.destroyed) return;
      const s = this.sel(); if (!s || !s.rangeCount) return;
      const r = s.getRangeAt(0);
      if (this.ed.contains(r.commonAncestorContainer)) { this.range = r.cloneRange(); this.updateState(); this.updateCtx(); }
    }
    focusEditor() {
      this.ed.focus({ preventScroll: true });
      if (this.range) { const s = this.sel(); s.removeAllRanges(); s.addRange(this.range); }
    }
    closestEl(selector) {
      if (!this.range) return null;
      let n = this.range.startContainer; if (n.nodeType === 3) n = n.parentElement;
      const el = n && n.closest ? n.closest(selector) : null;
      return el && this.ed.contains(el) ? el : null;
    }
    topBlock(node) { if (!node || node === this.ed || !this.ed.contains(node)) return null; while (node.parentNode !== this.ed) node = node.parentNode; return node; }
    caretInto(el, atStart) {
      this.ed.focus({ preventScroll: true });
      const r = document.createRange(); r.selectNodeContents(el); r.collapse(!!atStart);
      const s = this.sel(); s.removeAllRanges(); s.addRange(r); this.range = r.cloneRange();
    }
    exec(cmd, val) {
      this.focusEditor();
      try { document.execCommand('styleWithCSS', false, true); document.execCommand(cmd, false, val); } catch (e) { /* ignore */ }
      this.afterEdit();
    }
    afterEdit() { this.saveRange(); this.updateState(); this.onInput(); }
    updateState() {
      const q = (c) => { try { return document.queryCommandState(c); } catch (e) { return false; } };
      this.fmt.bold.classList.toggle('on', q('bold')); this.fmt.italic.classList.toggle('on', q('italic'));
      this.fmt.underline.classList.toggle('on', q('underline')); this.fmt.strike.classList.toggle('on', q('strikeThrough'));
      this.fmt.h1.classList.toggle('on', !!this.closestEl('h1')); this.fmt.h2.classList.toggle('on', !!this.closestEl('h2'));
      if (this.range) {
        let n = this.range.startContainer; if (n.nodeType === 3) n = n.parentElement;
        if (n && n.nodeType === 1) {
          const cs = getComputedStyle(n); this.sizeBtn.textContent = String(Math.round(parseFloat(cs.fontSize) || 14));
          const fam = (cs.fontFamily || '').split(',')[0].replace(/["']/g, '').trim(); const f = FONTS.find((x) => x[1].split(',')[0].replace(/["']/g, '').trim() === fam);
          this.fontBtn.textContent = f ? f[0] : (fam.length > 9 ? fam.slice(0, 8) + '…' : fam || 'Font');
        }
      }
    }
    fixFonts() {
      this.ed.querySelectorAll('font[size]').forEach((f) => {
        const s = f.getAttribute('size'); f.removeAttribute('size');
        f.style.fontSize = (s === '7' && this.pendingSize ? this.pendingSize : FONT_MAP[s] || 16) + 'px';
      });
    }

    /* ---- editing commands ---- */
    toggleHeading(tag) {
      this.focusEditor();
      const active = this.closestEl(tag.toLowerCase());
      document.execCommand('formatBlock', false, active ? 'div' : tag);
      this.afterEdit();
    }
    clearFormat() {
      this.focusEditor();
      document.execCommand('removeFormat'); document.execCommand('unlink');
      if (this.closestEl('h1,h2,h3')) document.execCommand('formatBlock', false, 'div');
      this.afterEdit();
    }
    applySize(px) {
      this.focusEditor(); this.pendingSize = px;
      document.execCommand('styleWithCSS', false, false); document.execCommand('fontSize', false, '7'); document.execCommand('styleWithCSS', false, true);
      this.fixFonts(); this.afterEdit(); this.sizeBtn.textContent = String(px);
    }
    insertHtml(html) { this.focusEditor(); document.execCommand('insertHTML', false, html); this.ed.querySelectorAll('.sl-img').forEach((s) => { s.contentEditable = 'false'; }); this.afterEdit(); }
    makeCheck(text, done) {
      const tmp = document.createElement('div'); tmp.innerHTML = SL.checkHtml(text || '', done); return tmp.firstChild;
    }
    addChecklist() {
      this.focusEditor();
      const line = this.makeCheck('');
      const block = this.range ? this.topBlock(this.range.startContainer) : null;
      if (!block) this.ed.append(line);
      else if (block.nodeType === 1 && block.classList.contains('sl-check')) block.after(line);
      else {
        const empty = block.nodeType === 1 && !block.textContent.replace(/\u200b/g, '').trim() && !block.querySelector('img,table,.sl-img');
        if (empty) block.replaceWith(line); else block.after(line);
      }
      this.caretInto(line.querySelector('.sl-ct'));
      const t = line.querySelector('.sl-ct'); const r = document.createRange(); r.selectNodeContents(t); r.collapse(false); const s = this.sel(); s.removeAllRanges(); s.addRange(r); this.range = r.cloneRange();
      this.afterEdit();
    }
    async insertTableDialog() {
      const r = h('input', { class: 'sl-input sm', type: 'number', min: '1', max: '30', value: '3' }); const c = h('input', { class: 'sl-input sm', type: 'number', min: '1', max: '12', value: '3' });
      const v = await UI.modal({ title: 'Insert table', width: 340, enterButton: 1, body: h('div', { class: 'sl-grid2' }, h('label', { class: 'sl-label', text: 'Rows' }), h('label', { class: 'sl-label', text: 'Columns' }), r, c), buttons: [{ label: 'Cancel', kind: 'ghost', value: null }, { label: 'Insert', kind: 'primary', value: '__ok__' }] });
      if (v !== '__ok__') return;
      const rows = SL.clamp(parseInt(r.value, 10) || 3, 1, 30); const cols = SL.clamp(parseInt(c.value, 10) || 3, 1, 12);
      let html = '<table class="sl-table"><tbody>';
      for (let i = 0; i < rows; i++) { html += '<tr>'; for (let j = 0; j < cols; j++) html += '<td><br></td>'; html += '</tr>'; }
      this.insertHtml(html + '</tbody></table><div><br></div>');
      const cell = this.ed.querySelector('table.sl-table td'); if (cell) this.caretInto(cell, true);
      this.saveRange();
    }
    cellAtCaret() { return this.closestEl('td,th'); }
    tableOp(op) {
      const cell = this.cellAtCaret(); if (!cell) { UI.toast('Click inside a table cell first'); return; }
      const tr = cell.parentElement; const table = cell.closest('table'); const ci = cell.cellIndex; const mk = (c) => { c.innerHTML = '<br>'; };
      if (op === 'row+') { const nr = table.insertRow(tr.rowIndex + 1); for (let i = 0; i < tr.cells.length; i++) mk(nr.insertCell()); this.caretInto(nr.cells[Math.min(ci, nr.cells.length - 1)], true); }
      else if (op === 'row-') { if (table.rows.length <= 1) { this.removeTable(table); } else { const next = table.rows[tr.rowIndex + 1] || table.rows[tr.rowIndex - 1]; table.deleteRow(tr.rowIndex); this.caretInto(next.cells[Math.min(ci, next.cells.length - 1)], true); } }
      else if (op === 'col+') { Array.from(table.rows).forEach((r) => mk(r.insertCell(ci + 1))); this.caretInto(tr.cells[ci + 1], true); }
      else if (op === 'col-') { if (tr.cells.length <= 1) this.removeTable(table); else { Array.from(table.rows).forEach((r) => r.deleteCell(ci)); this.caretInto(tr.cells[Math.max(0, ci - 1)], true); } }
      else if (op === 'del') this.removeTable(table);
      this.saveRange(); this.onInput(); this.updateCtx();
    }
    removeTable(t) { const nx = t.nextElementSibling; t.remove(); if (nx) this.caretInto(nx, true); else this.ed.focus(); }

    /* ---- images / drawings ---- */
    pickImage() { this.saveRange(); this.fileIn.click(); }
    async insertImageFile(file) {
      try { const url = await UI.fileToDataUrl(file, 1600); this.insertImage(url); } catch (e) { UI.toast(e.message || 'Could not add image'); }
    }
    insertImage(url, w) {
      const span = '<span class="sl-img" style="width:' + (w || 240) + 'px"><img src="' + SL.esc(url) + '" alt="image"></span>';
      this.insertHtml(span + '&#8203;');
    }
    async newDrawing() {
      this.saveRange();
      const url = await UI.canvasEditor({ mode: 'draw', width: 560, height: 340 });
      if (url) this.insertImage(url, 300);
    }
    syncImgSize() { this.onInput(); }
    selectImage(span) {
      if (this.selImg) this.selImg.classList.remove('sl-sel');
      this.selImg = span; if (span) span.classList.add('sl-sel');
      this.updateCtx();
    }
    async editImage(mode) {
      const sp = this.selImg; if (!sp) return; const img = sp.querySelector('img'); if (!img) return;
      const url = await UI.canvasEditor({ src: img.getAttribute('src'), mode });
      if (url) { img.setAttribute('src', url); sp.style.height = ''; this.onInput(); }
    }
    onEditorClick(e) {
      const sp = e.target.closest ? e.target.closest('.sl-img') : null;
      if (sp && this.ed.contains(sp)) {
        this.selectImage(sp);
        const r = document.createRange(); r.selectNode(sp); const s = this.sel(); s.removeAllRanges(); s.addRange(r);
      } else if (this.selImg) this.selectImage(null);
      const a = e.target.closest ? e.target.closest('a[href]') : null;
      if (a && (e.ctrlKey || e.metaKey)) window.open(a.href, '_blank', 'noopener');
    }
    updateCtx() {
      const bar = this.ctxBar; bar.innerHTML = '';
      const mk = (label, fn, cls) => { const b = h('button', { class: 'sl-chip ' + (cls || ''), type: 'button', text: label }); b.addEventListener('mousedown', (e) => e.preventDefault()); b.addEventListener('click', (e) => { e.preventDefault(); fn(); }); return b; };
      if (this.selImg && this.ed.contains(this.selImg)) {
        const setW = (w) => { this.selImg.style.width = w; this.selImg.style.height = ''; this.onInput(); };
        bar.append(h('span', { class: 'sl-ctx-t', text: 'Image' }), mk('S', () => setW('120px')), mk('M', () => setW('240px')), mk('L', () => setW('420px')), mk('Full', () => setW('100%')), mk('Crop', () => this.editImage('crop')), mk('Draw', () => this.editImage('draw')), mk('Delete', () => { const s = this.selImg; this.selectImage(null); s.remove(); this.onInput(); }, 'danger'));
        bar.classList.add('open'); return;
      }
      if (this.cellAtCaret()) {
        bar.append(h('span', { class: 'sl-ctx-t', text: 'Table' }), mk('+ Row', () => this.tableOp('row+')), mk('− Row', () => this.tableOp('row-')), mk('+ Col', () => this.tableOp('col+')), mk('− Col', () => this.tableOp('col-')), mk('Delete', () => this.tableOp('del'), 'danger'));
        bar.classList.add('open'); return;
      }
      bar.classList.remove('open');
    }
    onPaste(e) {
      const cd = e.clipboardData; if (!cd) return;
      const files = Array.from(cd.files || []).filter((f) => f.type.startsWith('image/'));
      e.preventDefault();
      if (files.length) { files.forEach((f) => this.insertImageFile(f)); return; }
      const html = cd.getData('text/html'); const text = cd.getData('text/plain');
      if (html) document.execCommand('insertHTML', false, SL.sanitize(html)); else if (text) document.execCommand('insertText', false, text);
    }
    onEditorKey(e) {
      const line = this.closestEl('.sl-check');
      if (line && e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const ct = line.querySelector('.sl-ct'); const txt = (ct ? ct.textContent : '').replace(/\u200b/g, '').trim();
        if (!txt) { const d = document.createElement('div'); d.innerHTML = '<br>'; line.replaceWith(d); this.caretInto(d, true); }
        else { const nl = this.makeCheck(''); line.after(nl); this.caretInto(nl.querySelector('.sl-ct')); }
        this.onInput(); return;
      }
      if (line && e.key === 'Backspace' && this.range && this.range.collapsed) {
        const ct = line.querySelector('.sl-ct');
        if (ct) {
          const pre = this.range.cloneRange(); pre.selectNodeContents(ct); pre.setEnd(this.range.startContainer, this.range.startOffset);
          if (!pre.toString().replace(/\u200b/g, '')) {
            e.preventDefault(); const d = document.createElement('div');
            if (ct.textContent.replace(/\u200b/g, '')) d.append(...Array.from(ct.childNodes)); else d.innerHTML = '<br>';
            line.replaceWith(d); this.caretInto(d, true); this.onInput(); return;
          }
        }
      }
      const cell = this.cellAtCaret();
      if (cell && e.key === 'Tab') {
        e.preventDefault(); const table = cell.closest('table'); const cells = Array.from(table.querySelectorAll('td,th')); const i = cells.indexOf(cell) + (e.shiftKey ? -1 : 1);
        if (i >= cells.length) { this.tableOp('row+'); return; }
        if (i >= 0) { this.caretInto(cells[i], true); this.saveRange(); }
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); this.openFind(); }
      if (this.selImg && (e.key === 'Delete' || e.key === 'Backspace')) { e.preventDefault(); const s = this.selImg; this.selectImage(null); s.remove(); this.onInput(); }
    }
    onKey(e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); this.commit({ force: true }).then(() => UI.toast('Saved')); }
      if (e.key === 'Escape' && this.pop) { e.stopPropagation(); this.closePop(); }
    }

    /* ---- popovers ---- */
    openPop(anchor, content, o) {
      o = o || {};
      if (this.pop && this.popAnchor === anchor) { this.closePop(); return; }
      this.closePop();
      const pop = h('div', { class: 'sl-pop ' + (o.cls || '') }, content);
      pop.addEventListener('mousedown', (e) => { if (!/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) e.preventDefault(); });
      this.root.append(pop); this.pop = pop; this.popAnchor = anchor;
      const rr = this.root.getBoundingClientRect(); const ar = anchor.getBoundingClientRect();
      pop.style.maxHeight = Math.max(120, rr.height - 12) + 'px'; pop.style.visibility = 'hidden';
      const pw = pop.offsetWidth; const ph = pop.offsetHeight;
      const left = SL.clamp(ar.left - rr.left, 6, Math.max(6, rr.width - pw - 6));
      let top = o.up ? ar.top - rr.top - ph - 6 : ar.bottom - rr.top + 6;
      top = SL.clamp(top, 6, Math.max(6, rr.height - ph - 6));
      pop.style.left = left + 'px'; pop.style.top = top + 'px'; pop.style.visibility = '';
      const rootNode = this.root.getRootNode();
      const off = (ev) => { const path = ev.composedPath ? ev.composedPath() : []; if (path.includes(pop) || path.includes(anchor)) return; this.closePop(); };
      setTimeout(() => rootNode.addEventListener('mousedown', off, true), 0);
      this.popOff = () => rootNode.removeEventListener('mousedown', off, true);
      return pop;
    }
    closePop() { if (this.pop) { this.pop.remove(); this.pop = null; this.popAnchor = null; } if (this.popOff) { this.popOff(); this.popOff = null; } }
    menuItem(label, fn, o) {
      o = o || {};
      return h('button', { class: 'sl-mi' + (o.danger ? ' danger' : '') + (o.on ? ' on' : ''), type: 'button', onclick: () => { if (!o.keep) this.closePop(); fn(); } },
        o.icon ? h('span', { class: 'sl-mi-i', html: SL.icon(o.icon, 15) }) : h('span', { class: 'sl-mi-i', text: o.on ? '✓' : '' }), h('span', { class: 'sl-mi-l', text: label }), o.key ? h('span', { class: 'sl-mi-k', text: o.key }) : null);
    }
    openFontMenu(anchor) {
      const list = h('div', { class: 'sl-menu' }, FONTS.map((f) => { const b = this.menuItem(f[0], () => { this.focusEditor(); document.execCommand('styleWithCSS', false, true); document.execCommand('fontName', false, f[1]); this.afterEdit(); }); b.style.fontFamily = f[1]; return b; }));
      this.openPop(anchor, list, { up: !this.note.toolbarHidden });
    }
    openSizeMenu(anchor) {
      const list = h('div', { class: 'sl-menu narrow' }, SIZES.map((s) => this.menuItem(s + ' px', () => this.applySize(s))));
      this.openPop(anchor, list, { up: true });
    }
    openColorMenu(anchor) {
      const n = this.note;
      const noteSw = SL.COLORS.map((c) => h('button', { class: 'sl-sw' + (n.color.toLowerCase() === c.hex.toLowerCase() ? ' on' : ''), type: 'button', title: c.name, style: { background: c.hex }, onclick: () => { n.color = c.hex; this.applyStyle(); this.commit({ touch: false }); this.closePop(); } }));
      const wheel1 = h('label', { class: 'sl-sw wheel', title: 'Color wheel' }, h('input', { type: 'color', value: n.color, oninput: (e) => { n.color = e.target.value; this.applyStyle(); }, onchange: () => this.commit({ touch: false }) }));
      const inks = ['#1f2328', '#ffffff', '#c92a2a', '#1971c2', '#2b8a3e', '#862e9c'];
      const inkSw = [h('button', { class: 'sl-sw auto' + (!n.textColor ? ' on' : ''), type: 'button', title: 'Automatic', text: 'A', onclick: () => { n.textColor = ''; this.applyStyle(); this.commit({ touch: false }); this.closePop(); } })].concat(inks.map((c) => h('button', { class: 'sl-sw' + (n.textColor === c ? ' on' : ''), type: 'button', style: { background: c }, title: c, onclick: () => { n.textColor = c; this.applyStyle(); this.commit({ touch: false }); this.closePop(); } })));
      const wheel2 = h('label', { class: 'sl-sw wheel', title: 'Text color wheel' }, h('input', { type: 'color', value: n.textColor || SL.contrast(n.color), oninput: (e) => { n.textColor = e.target.value; this.applyStyle(); }, onchange: () => this.commit({ touch: false }) }));
      this.openPop(anchor, h('div', { class: 'sl-colors' }, h('div', { class: 'sl-ph', text: 'Note color' }), h('div', { class: 'sl-sws' }, noteSw, wheel1), h('div', { class: 'sl-ph', text: 'Text color' }), h('div', { class: 'sl-sws' }, inkSw, wheel2)));
    }
    async openLabelMenu(anchor) {
      const n = this.note; const all = this.opts.allTags ? await this.opts.allTags() : n.tags;
      const known = Array.from(new Set(all.concat(n.tags))).sort();
      const wrap = h('div', { class: 'sl-labels' });
      const input = h('input', { class: 'sl-input sm', placeholder: 'New label, press Enter', maxlength: '40' });
      const render = () => {
        wrap.innerHTML = '';
        known.forEach((t) => wrap.append(h('button', { class: 'sl-tagchip' + (n.tags.includes(t) ? ' on' : ''), type: 'button', text: t, onclick: () => { n.tags = n.tags.includes(t) ? n.tags.filter((x) => x !== t) : n.tags.concat(t); this.commit({ touch: false }); this.updateMeta(); render(); } })));
        if (!known.length) wrap.append(h('span', { class: 'sl-hint', text: 'No labels yet' }));
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); const t = input.value.trim().slice(0, 40); if (!t) return; if (!known.includes(t)) known.push(t); if (!n.tags.includes(t)) n.tags = n.tags.concat(t); input.value = ''; this.commit({ touch: false }); this.updateMeta(); render(); }
      });
      render();
      this.openPop(anchor, h('div', { class: 'sl-labelpop' }, h('div', { class: 'sl-ph', text: 'Labels' }), wrap, input), {});
      setTimeout(() => input.focus(), 20);
    }
    openMoreMenu(anchor) {
      const n = this.note; const menu = h('div', { class: 'sl-menu' });
      const add = (...a) => menu.append(this.menuItem(...a));
      add('Make a copy', () => this.copy(), { icon: 'copy' });
      add('Find & replace', () => this.openFind(), { icon: 'search', key: 'Ctrl+F' });
      add('Version history', () => this.openHistory(), { icon: 'history' });
      add('Set reminder…', () => this.openReminder(), { icon: 'bell' });
      menu.append(h('div', { class: 'sl-ph', text: 'Show this note on' }));
      [['url', 'This page only'], ['domain', 'Whole website'], ['global', 'All websites'], ['none', 'Dashboard only']].forEach(([v, l]) => add(l, () => this.setScope(v), { on: n.scope === v, keep: false }));
      add('Link to other pages / sites…', () => this.editLinks(), { icon: 'globe' });
      add('Change source URL…', () => this.changeUrl(), { icon: 'link' });
      if (n.url) add('Open source page', () => window.open(n.url, '_blank', 'noopener'), { icon: 'external' });
      menu.append(h('div', { class: 'sl-sep' }));
      if (!n.locked) add('Lock with password…', () => this.lockDialog(), { icon: 'lock' });
      else { add('Lock now', () => this.relock(), { icon: 'lock' }); add('Remove password', () => this.removeLock(), { icon: 'lock' }); }
      add('Export…', () => this.exportDialog(), { icon: 'download' });
      add(n.archived ? 'Unarchive' : 'Archive', () => this.archive(), { icon: 'archive' });
      add('Delete note', () => this.del(), { icon: 'trash', danger: true });
      this.openPop(anchor, menu, {});
    }

    /* ---- find & replace ---- */
    openFind() { if (this.findBar.classList.contains('open')) { this.findIn.focus(); return; } this.findBar.classList.add('open'); this.findIn.focus(); this.findIn.select(); this.runFind(); }
    closeFind() { this.findBar.classList.remove('open'); this.clearMarks(); this.ed.focus(); }
    clearMarks() { this.ed.querySelectorAll('mark.sl-hit').forEach((m) => m.replaceWith(document.createTextNode(m.textContent))); this.ed.normalize(); this.marks = []; this.cur = -1; this.cnt.textContent = ''; }
    runFind() {
      this.clearMarks(); const q = this.findIn.value; if (!q) return;
      const cs = this.caseCb.checked; const needle = cs ? q : q.toLowerCase();
      const w = document.createTreeWalker(this.ed, NodeFilter.SHOW_TEXT); const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
      nodes.forEach((tn) => {
        const text = cs ? tn.nodeValue : tn.nodeValue.toLowerCase(); const idx = []; let i = 0;
        while ((i = text.indexOf(needle, i)) > -1) { idx.push(i); i += needle.length; }
        for (let k = idx.length - 1; k >= 0; k--) { const r = document.createRange(); r.setStart(tn, idx[k]); r.setEnd(tn, idx[k] + q.length); const m = document.createElement('mark'); m.className = 'sl-hit'; r.surroundContents(m); }
      });
      this.marks = Array.from(this.ed.querySelectorAll('mark.sl-hit')); this.cur = -1; this.stepFind(1);
    }
    stepFind(d) {
      if (!this.marks.length) { this.cnt.textContent = this.findIn.value ? '0 found' : ''; return; }
      this.cur = (this.cur + d + this.marks.length) % this.marks.length;
      this.marks.forEach((m) => m.classList.remove('cur')); const m = this.marks[this.cur]; m.classList.add('cur');
      m.scrollIntoView({ block: 'center', behavior: 'smooth' }); this.cnt.textContent = (this.cur + 1) + ' / ' + this.marks.length;
    }
    replaceOne() {
      if (this.cur < 0 || !this.marks[this.cur]) { UI.toast('Nothing to replace'); return; }
      this.marks[this.cur].replaceWith(document.createTextNode(this.repIn.value)); this.marks.splice(this.cur, 1); this.cur -= 1;
      this.onInput(); if (this.marks.length) this.stepFind(1); else this.cnt.textContent = '0 found';
    }
    replaceAll() {
      const c = this.marks.length; if (!c) { UI.toast('Nothing to replace'); return; }
      this.marks.forEach((m) => m.replaceWith(document.createTextNode(this.repIn.value))); this.ed.normalize(); this.marks = []; this.cur = -1; this.cnt.textContent = '0 found';
      this.onInput(); UI.toast('Replaced ' + c + (c === 1 ? ' match' : ' matches'));
    }

    /* ---- reminders ---- */
    async openReminder() {
      const r = this.note.reminder; const at = r && r.at ? r.at : Date.now() + 3600000;
      const dt = h('input', { class: 'sl-input', type: 'datetime-local', value: toLocalInput(at) });
      const msg = h('input', { class: 'sl-input', placeholder: 'Optional message', maxlength: '300', value: r && r.message ? r.message : '' });
      const rep = h('select', { class: 'sl-input' }, [['none', 'Does not repeat'], ['daily', 'Every day'], ['weekdays', 'Every weekday (Mon–Fri)'], ['weekly', 'Every week'], ['monthly', 'Every month'], ['yearly', 'Every year']].map(([v, l]) => h('option', { value: v, text: l })));
      rep.value = r && r.repeat ? r.repeat : 'none';
      const err = h('div', { class: 'sl-lock-err' });
      const quick = (label, ms) => h('button', { class: 'sl-chip', type: 'button', text: label, onclick: () => { dt.value = toLocalInput(Date.now() + ms); } });
      const tomorrow = () => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d.getTime() - Date.now(); };
      const buttons = [{ label: 'Cancel', kind: 'ghost', value: null }];
      if (r && r.at) buttons.push({ label: 'Remove', kind: 'danger', value: '__rm__' });
      buttons.push({
        label: 'Save reminder', kind: 'primary', value: '__ok__', onClick: () => {
          const t = new Date(dt.value).getTime();
          if (isNaN(t)) { err.textContent = 'Please choose a valid date and time.'; return false; }
          if (t < Date.now() - 60000 && rep.value === 'none') { err.textContent = 'Choose a time in the future.'; return false; }
        }
      });
      const v = await UI.modal({
        title: 'Reminder', width: 400,
        body: h('div', null, h('label', { class: 'sl-label', text: 'When' }), dt, h('div', { class: 'sl-quick' }, quick('In 10 min', 600000), quick('In 1 hour', 3600000), quick('Tomorrow 9 AM', tomorrow())),
          h('label', { class: 'sl-label', text: 'Message' }), msg, h('label', { class: 'sl-label', text: 'Repeat' }), rep, err, h('p', { class: 'sl-hint', text: 'You will get a browser notification and an in-page pop-up.' })),
        buttons
      });
      if (v === '__rm__') { this.note.reminder = null; await this.commit({ touch: false }); this.updateMeta(); UI.toast('Reminder removed'); }
      else if (v === '__ok__') {
        this.note.reminder = { at: new Date(dt.value).getTime(), repeat: rep.value, message: msg.value.trim(), fired: false };
        await this.commit({ touch: false }); this.updateMeta(); UI.toast('Reminder set for ' + SL.fmtDateTime(this.note.reminder.at));
      }
    }

    /* ---- more-menu actions ---- */
    async copy() { await this.commit({ touch: false }); const c = SL.notes.duplicate(this.note); if (this.unlocked && this.note.locked) { /* copy stays encrypted */ } await SL.notes.save(c); UI.toast('Copy created'); if (this.opts.onCopy) this.opts.onCopy(c); }
    async setScope(v) {
      const n = this.note;
      if ((v === 'url' || v === 'domain') && !n.url) { await this.changeUrl(); if (!n.url) return; }
      n.scope = v; await this.commit({ touch: false }); UI.toast(v === 'none' ? 'Note is now dashboard-only' : 'Binding updated');
    }
    async editLinks() {
      const v = await UI.prompt({ title: 'Link to other pages or websites', label: 'One per line — a domain (example.com) or a URL prefix (example.com/docs)', multiline: true, value: (this.note.links || []).join('\n'), okLabel: 'Save links', hint: 'This note will also appear on every matching page.' });
      if (v == null) return;
      this.note.links = v.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 50);
      await this.commit({ touch: false }); UI.toast(this.note.links.length ? 'Linked to ' + this.note.links.length + ' site(s)' : 'Links cleared');
    }
    async changeUrl() {
      const v = await UI.prompt({ title: 'Source page URL', label: 'Page this note belongs to', value: this.note.url || 'https://', okLabel: 'Save', type: 'url' });
      if (v == null) return;
      try { const u = new URL(v.trim()); if (!/^https?:$/.test(u.protocol)) throw new Error(); this.note.url = u.href; if (this.note.scope === 'none') this.note.scope = 'url'; await this.commit({ touch: false }); this.updateMeta(); }
      catch (e) { if (v.trim() && v.trim() !== 'https://') UI.toast('That does not look like a valid http(s) URL'); }
    }
    async openHistory() {
      const n = this.note;
      if (n.locked) { UI.alert('Version history is not kept for password-protected notes so that no readable copies exist.', 'Locked note'); return; }
      await this.commit({ touch: false });
      const vs = (n.versions || []).slice().reverse();
      const list = h('div', { class: 'sl-vers' });
      if (!vs.length) list.append(h('p', { class: 'sl-hint', text: 'No earlier versions yet. Versions are captured automatically as you edit (and whenever you press Ctrl+S).' }));
      vs.forEach((v) => {
        const prev = h('div', { class: 'sl-ver-prev' }); prev.innerHTML = SL.sanitize(v.html) || '<i>(empty)</i>';
        list.append(h('div', { class: 'sl-ver' }, h('div', { class: 'sl-ver-h' }, h('b', { text: v.title || 'Untitled' }), h('span', { text: SL.fmtDateTime(v.t) }), h('button', { class: 'sl-btn primary sm', type: 'button', text: 'Restore', onclick: () => { this.restore(v); ctl.close(); } })), prev));
      });
      let ctl; UI.modal({ title: 'Version history', width: 560, body: (c) => { ctl = c; return list; }, buttons: [{ label: 'Close', kind: 'ghost' }] });
    }
    async restore(v) {
      const n = this.note; n.versions = (n.versions || []).concat({ t: Date.now(), title: n.title, html: n.html }).slice(-30);
      this.titleEl.value = v.title || ''; this.setEditorHtml(v.html); await this.commit({ force: true, noVersion: true }); UI.toast('Version restored');
    }
    async exportDialog() {
      await this.commit({ touch: false });
      const n = this.note; const src = this.exportSource();
      const btns = SL.fmt.FORMATS.map((f) => h('button', { class: 'sl-fmt', type: 'button', onclick: () => { if (n.locked && !this.unlocked && f.id !== 'json') { UI.toast('Unlock the note first'); return; } const out = SL.fmt.exportNote(src, f.id); SL.fmt.download(out.name, out.mime, out.data); ctl.close(); UI.toast('Exported ' + out.name); } }, h('b', { text: f.label }), h('small', { text: f.desc })));
      let ctl; UI.modal({ title: 'Export this note', width: 420, body: (c) => { ctl = c; return h('div', { class: 'sl-fmts' }, btns); }, buttons: [{ label: 'Close', kind: 'ghost' }] });
    }
    exportSource() { const n = this.note; if (n.locked && this.unlocked) return Object.assign({}, n, { locked: false, html: this.getHtml(), cipher: null }); return n; }
    async archive() {
      const n = this.note; n.archived = !n.archived; n.open = true; await this.commit({ touch: false });
      UI.toast(n.archived ? 'Note archived' : 'Note restored from archive');
      if (n.archived) { this.destroy(); if (this.opts.onClose) this.opts.onClose(this, 'archived'); }
    }
    async del() {
      const ok = await UI.confirm('Delete "' + (this.note.title || 'Untitled') + '" permanently? This cannot be undone.', { title: 'Delete note', okLabel: 'Delete', danger: true });
      if (!ok) return;
      clearTimeout(this.saveTimer); this.dirty = false;
      await SL.notes.remove(this.note.id); const id = this.note.id; this.destroy(); UI.toast('Note deleted');
      if (this.opts.onDeleted) this.opts.onDeleted(id);
    }

    /* ---- locking ---- */
    showLock() { this.lockEl.classList.add('open'); this.root.classList.add('sl-locked'); this.ed.innerHTML = ''; this.lockMsg.textContent = ''; this.lockPw.value = ''; this.unlocked = false; this.sessionPw = null; }
    hideLock() { this.lockEl.classList.remove('open'); this.root.classList.remove('sl-locked'); }
    async unlock() {
      const pw = this.lockPw.value; if (!pw) { this.lockMsg.textContent = 'Enter the password.'; return; }
      try {
        const html = await SL.decrypt(this.note.cipher, pw);
        this.sessionPw = pw; this.unlocked = true; this.hideLock(); this.setEditorHtml(html); this.ed.focus();
      } catch (e) {
        this.lockMsg.textContent = e && e.message === 'NO_SUBTLE' ? 'Encryption needs a secure (https) page. Open this note from the dashboard instead.' : 'Wrong password. Try again.';
        this.lockEl.classList.remove('shake'); void this.lockEl.offsetWidth; this.lockEl.classList.add('shake');
      }
    }
    async lockDialog() {
      if (!SL.canEncrypt()) { UI.alert('Password encryption needs a secure context. This page is not served over HTTPS, so please lock this note from the All Notes dashboard.', 'Encryption unavailable'); return; }
      const p1 = h('input', { class: 'sl-input', type: 'password', placeholder: 'Password (min. 6 characters)', autocomplete: 'new-password', 'data-autofocus': '' });
      const p2 = h('input', { class: 'sl-input', type: 'password', placeholder: 'Repeat password', autocomplete: 'new-password' });
      const ack = h('input', { type: 'checkbox' }); const err = h('div', { class: 'sl-lock-err' });
      const v = await UI.modal({
        title: 'Lock note with a password', width: 440,
        body: h('div', null,
          h('div', { class: 'sl-warn', html: '<b>Important:</b> your password is never stored or sent anywhere. <b>If you forget it, this note can NOT be recovered</b> — not by you, not by us.' }),
          h('label', { class: 'sl-label', text: 'Password' }), p1, h('label', { class: 'sl-label', text: 'Confirm' }), p2,
          h('label', { class: 'sl-inline sl-ack' }, ack, ' I understand that a lost password cannot be recovered.'), err),
        buttons: [{ label: 'Cancel', kind: 'ghost', value: null }, {
          label: 'Encrypt & lock', kind: 'primary', value: '__ok__', onClick: () => {
            if (p1.value.length < 6) { err.textContent = 'Use at least 6 characters.'; return false; }
            if (p1.value !== p2.value) { err.textContent = 'Passwords do not match.'; return false; }
            if (!ack.checked) { err.textContent = 'Please confirm that you understand the warning.'; return false; }
          }
        }]
      });
      if (v !== '__ok__') return;
      clearTimeout(this.saveTimer);
      const n = this.note; n.cipher = await SL.encrypt(this.getHtml(), p1.value); n.locked = true; n.html = ''; n.versions = []; n.updatedAt = Date.now(); n.rev = (n.rev || 0) + 1;
      await SL.notes.save(n); this.dirty = false; this.showLock(); this.updateMeta(); UI.toast('Note locked');
    }
    relock() { this.flush().then(() => { this.showLock(); UI.toast('Note locked'); }); }
    async removeLock() {
      if (!this.unlocked) { UI.toast('Unlock the note first'); return; }
      const ok = await UI.confirm('Remove password protection? The note will be stored without encryption.', { title: 'Remove password', okLabel: 'Remove', danger: true });
      if (!ok) return;
      const n = this.note; n.html = this.getHtml(); n.locked = false; n.cipher = null; this.sessionPw = null; this.unlocked = false; n.rev = (n.rev || 0) + 1;
      await SL.notes.save(n); UI.toast('Password removed');
    }

    /* ---- saving ---- */
    getHtml() {
      const c = this.ed.cloneNode(true);
      c.querySelectorAll('.sl-sel').forEach((e) => e.classList.remove('sl-sel'));
      const html = SL.sanitize(c.innerHTML);
      return !this.ed.textContent.replace(/\u200b/g, '').trim() && !this.ed.querySelector('img,table,.sl-check') ? '' : html;
    }
    onInput() {
      this.dirty = true; this.toggleEmpty();
      const auto = this.opts.autoSave ? this.opts.autoSave() : true;
      clearTimeout(this.saveTimer);
      if (auto) this.saveTimer = setTimeout(() => this.commit(), 600);
      this.updateMeta();
    }
    flush() { if (this.dirty) return this.commit({ force: true }); return Promise.resolve(); }
    async commit(o) {
      o = o || {}; if (this.destroyed) return;
      clearTimeout(this.saveTimer);
      const n = this.note; const touch = o.touch !== false && (this.dirty || o.force);
      const auto = this.opts.autoSave ? this.opts.autoSave() : true;
      n.title = this.titleEl.value.slice(0, 200);
      if (n.locked) {
        if (this.unlocked && this.sessionPw && (this.dirty || o.force)) { try { n.cipher = await SL.encrypt(this.getHtml(), this.sessionPw, n.cipher && n.cipher.s); } catch (e) { UI.toast('Could not encrypt the note'); return; } }
      } else if (this.dirty || o.force) {
        const html = this.getHtml();
        if (!o.noVersion && n.html && html !== n.html) {
          const vs = n.versions = n.versions || []; const last = vs[vs.length - 1];
          if (o.force || !last || (Date.now() - last.t > 120000 && last.html !== n.html)) { vs.push({ t: Date.now(), title: n.title, html: n.html }); if (vs.length > 30) vs.shift(); }
        }
        n.html = html;
      }
      if (touch) n.updatedAt = Date.now();
      n.rev = (n.rev || 0) + 1; this.dirty = false;
      try { await SL.notes.save(n); } catch (e) { UI.toast('Could not save – storage error'); }
      void auto; this.updateMeta();
    }
    persistGeom() { return this.commit({ touch: false }); }
    applyRemote(nn) {
      if (this.destroyed || !nn || (nn.rev || 0) <= (this.note.rev || 0)) return;
      const focused = this.root.contains(this.root.getRootNode().activeElement);
      if (focused && this.dirty) return;
      const wasLocked = this.note.locked; this.note = nn;
      if (!(nn.locked && this.unlocked && wasLocked)) { this.unlocked = nn.locked ? false : this.unlocked; }
      this.refresh();
    }

    /* ---- drag & resize ---- */
    initDrag() {
      this.head.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || e.target.closest('button,input')) return;
        const n = this.note; const sx = e.clientX; const sy = e.clientY; const ox = n.x; const oy = n.y; const el = this.head;
        el.setPointerCapture(e.pointerId); this.root.classList.add('sl-dragging'); this.closePop();
        const move = (ev) => { n.x = ox + ev.clientX - sx; n.y = oy + ev.clientY - sy; this.place(); n.x = parseFloat(this.root.style.left); n.y = parseFloat(this.root.style.top); };
        const up = () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); this.root.classList.remove('sl-dragging'); this.persistGeom(); };
        el.addEventListener('pointermove', move); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
        e.preventDefault();
      });
    }
    initResize() {
      this.root.querySelectorAll('.sl-rz').forEach((hd) => {
        hd.addEventListener('pointerdown', (e) => {
          if (e.button !== 0) return; e.preventDefault(); e.stopPropagation(); this.closePop();
          const dir = hd.dataset.dir; const n = this.note; const r = this.root.getBoundingClientRect();
          const s = { x: r.left, y: r.top, w: r.width, h: r.height }; const sx = e.clientX; const sy = e.clientY;
          hd.setPointerCapture(e.pointerId); this.root.classList.add('sl-dragging');
          const move = (ev) => {
            const dx = ev.clientX - sx; const dy = ev.clientY - sy; let { x, y, w, h: hh } = s;
            if (dir.includes('e')) w = Math.max(MINW, s.w + dx);
            if (dir.includes('s')) hh = Math.max(MINH, s.h + dy);
            if (dir.includes('w')) { w = Math.max(MINW, s.w - dx); x = s.x + s.w - w; }
            if (dir.includes('n')) { hh = Math.max(MINH, s.h - dy); y = s.y + s.h - hh; }
            Object.assign(n, { x, y, w, h: hh }); this.place();
          };
          const up = () => { hd.removeEventListener('pointermove', move); hd.removeEventListener('pointerup', up); hd.removeEventListener('pointercancel', up); this.root.classList.remove('sl-dragging'); this.persistGeom(); };
          hd.addEventListener('pointermove', move); hd.addEventListener('pointerup', up); hd.addEventListener('pointercancel', up);
        });
      });
    }

    /* ---- lifecycle ---- */
    async close() {
      await this.flush();
      if (!this.embedded) { this.note.open = false; await this.commit({ touch: false }); }
      this.destroy();
      if (this.opts.onClose) this.opts.onClose(this, 'closed');
    }
    focus() { this.bump(); if (!this.note.locked || this.unlocked) this.ed.focus({ preventScroll: true }); else this.lockPw.focus(); }
    destroy() {
      if (this.destroyed) return; this.destroyed = true;
      clearTimeout(this.saveTimer); this.closePop(); document.removeEventListener('selectionchange', this.selListener); this.root.remove();
    }
  }
  SL.NoteWindow = NoteWindow;
})(typeof globalThis !== 'undefined' ? globalThis : window);
