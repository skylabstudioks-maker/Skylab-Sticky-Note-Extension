/* Skylab Sticky Note – All Notes dashboard */
(async function () {
  'use strict';
  const h = SL.h; const $ = (id) => document.getElementById(id);
  const layer = $('modalLayer'); SL.ui.setLayer(layer);
  const state = { notes: [], settings: Object.assign({}, SL.DEFAULTS), view: 'all', q: '', selecting: false, sel: new Set(), editor: null };
  const ico = (n, s) => SL.icon(n, s || 16);
  const textCache = new Map();
  const noteText = (n) => { if (n.locked) return ''; const k = n.id + ':' + n.rev + ':' + n.updatedAt; if (!textCache.has(k)) { if (textCache.size > 800) textCache.clear(); textCache.set(k, SL.textOf(n.html)); } return textCache.get(k); };
  const toast = (m, o) => SL.ui.toast(m, o);

  /* ------------------------------------------------------------ data helpers */
  async function reload() {
    state.notes = await SL.notes.all(); state.settings = await SL.settings.get(); applyTheme(); render();
  }
  const allTags = () => Array.from(new Set(state.notes.flatMap((n) => n.tags || []))).sort((a, b) => a.localeCompare(b));
  function applyTheme() {
    const t = state.settings.theme; const dark = t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    $('btnTheme').innerHTML = ico(dark ? 'sun' : 'eye', 17);
  }
  function filtered() {
    const v = state.view; let list = state.notes.slice();
    if (v === 'archived') list = list.filter((n) => n.archived);
    else list = list.filter((n) => !n.archived);
    if (v === 'pinned') list = list.filter((n) => n.pinned);
    else if (v === 'reminders') list = list.filter((n) => n.reminder && n.reminder.at);
    else if (v === 'locked') list = list.filter((n) => n.locked);
    else if (v.startsWith('tag:')) list = list.filter((n) => (n.tags || []).includes(v.slice(4)));
    else if (v.startsWith('site:')) list = list.filter((n) => SL.host(n.url) === v.slice(5));
    const toks = state.q.toLowerCase().split(/\s+/).filter(Boolean);
    if (toks.length) list = list.filter((n) => { const hay = [n.title, noteText(n), (n.tags || []).join(' '), n.url, n.pageTitle].join(' \n ').toLowerCase(); return toks.every((t) => hay.includes(t)); });
    const s = state.settings.sort;
    list.sort((a, b) => {
      if (v === 'reminders') return a.reminder.at - b.reminder.at;
      if (!!b.pinned !== !!a.pinned) return b.pinned ? 1 : -1;
      if (s === 'title') return (a.title || 'zzz').localeCompare(b.title || 'zzz');
      if (s === 'created') return b.createdAt - a.createdAt;
      if (s === 'site') return SL.host(a.url).localeCompare(SL.host(b.url)) || b.updatedAt - a.updatedAt;
      return b.updatedAt - a.updatedAt;
    });
    return list;
  }

  /* -------------------------------------------------------------- navigation */
  function renderNav() {
    const nav = $('nav'); nav.textContent = '';
    const active = state.notes.filter((n) => !n.archived);
    const item = (view, icon, label, count) => nav.append(h('button', { class: 'd-nav' + (state.view === view ? ' on' : ''), type: 'button', onclick: () => go(view) }, h('span', { html: ico(icon) }), h('span', { class: 't', text: label }), count != null ? h('span', { class: 'c', text: String(count) }) : null));
    item('all', 'note', 'All notes', active.length);
    item('pinned', 'pin', 'Pinned', active.filter((n) => n.pinned).length);
    item('reminders', 'bell', 'Reminders', active.filter((n) => n.reminder && n.reminder.at).length);
    item('locked', 'lock', 'Locked', active.filter((n) => n.locked).length);
    item('archived', 'archive', 'Archive', state.notes.filter((n) => n.archived).length);
    const sites = {}; active.forEach((n) => { const hn = SL.host(n.url); if (hn) sites[hn] = (sites[hn] || 0) + 1; });
    const sk = Object.keys(sites).sort((a, b) => sites[b] - sites[a]).slice(0, 8);
    if (sk.length) { nav.append(h('div', { class: 'd-nav-h', text: 'Websites' })); sk.forEach((s) => item('site:' + s, 'globe', s, sites[s])); }
    const tg = allTags();
    if (tg.length) { nav.append(h('div', { class: 'd-nav-h', text: 'Labels' })); tg.forEach((t) => item('tag:' + t, 'tag', t, active.filter((n) => (n.tags || []).includes(t)).length)); }
    nav.append(h('div', { class: 'd-nav-h', text: 'Manage' }));
    item('data', 'download', 'Import & export'); item('settings', 'settings', 'Settings');
  }
  function go(view) {
    state.view = view; state.sel.clear(); $('side').classList.remove('open'); $('scrim').classList.remove('open');
    if (view === 'settings' || view === 'data') state.selecting = false;
    render();
  }

  /* ----------------------------------------------------------------- render */
  function render() {
    renderNav();
    const isNotes = state.view !== 'data' && state.view !== 'settings';
    $('searchWrap').style.visibility = isNotes ? '' : 'hidden';
    ['sort', 'layoutSeg', 'btnSelect'].forEach((id) => { $(id).style.display = isNotes ? '' : 'none'; });
    $('sort').value = state.settings.sort;
    $('layoutSeg').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.l === state.settings.layout));
    $('btnSelect').classList.toggle('on', state.selecting);
    $('btnSelect').textContent = state.selecting ? 'Done' : 'Select';
    renderBulk();
    const c = $('content'); const sc = c.scrollTop; c.textContent = '';
    if (state.view === 'settings') renderSettings(c);
    else if (state.view === 'data') renderData(c);
    else renderNotes(c);
    c.scrollTop = sc;
  }
  const TITLES = { all: 'All notes', pinned: 'Pinned', reminders: 'Reminders', locked: 'Locked notes', archived: 'Archive' };
  function viewTitle() { const v = state.view; return TITLES[v] || (v.startsWith('tag:') ? '# ' + v.slice(4) : v.startsWith('site:') ? v.slice(5) : ''); }

  function renderNotes(c) {
    const list = filtered();
    c.append(h('div', { class: 'd-h' }, h('h2', { text: viewTitle() }), h('span', { text: list.length + (list.length === 1 ? ' note' : ' notes') + (state.q ? ' matching “' + state.q + '”' : '') })));
    if (!list.length) {
      const msg = state.q ? ['🔍', 'No matches', 'Try different keywords.'] : state.view === 'archived' ? ['🗄️', 'Archive is empty', 'Archived notes are hidden from websites but never deleted.'] : state.view === 'reminders' ? ['⏰', 'No reminders', 'Add one from the bell icon inside a note.'] : ['📝', 'No notes yet', 'Create one here or on any website with the floating icon.'];
      c.append(h('div', { class: 'd-empty' }, h('div', { class: 'big', text: msg[0] }), h('h3', { text: msg[1] }), h('p', { text: msg[2] }), state.view === 'all' && !state.q ? h('button', { class: 'd-btn primary', type: 'button', text: '+ New note', onclick: newNote }) : null));
      return;
    }
    const grid = h('div', { class: 'd-grid' + (state.settings.layout === 'list' ? ' list' : '') });
    list.forEach((n) => grid.append(card(n)));
    c.append(grid);
  }
  function card(n) {
    const rgb = SL.hexToRgb(n.color).join(','); const ink = SL.contrast(n.color);
    const el = h('article', { class: 'd-card' + (state.sel.has(n.id) ? ' sel' : '') + (state.selecting ? ' selecting' : ''), tabindex: '0', role: 'button', 'aria-label': 'Open note ' + (n.title || 'Untitled') });
    el.style.setProperty('--note', n.color); el.style.setProperty('--note-rgb', rgb); el.style.setProperty('--ink', ink); el.style.setProperty('--body-ink', n.textColor || ink);
    const act = (icon, title, fn, cls) => h('button', { type: 'button', title, class: cls || '', html: ico(icon, 14), onclick: (e) => { e.stopPropagation(); fn(); } });
    const when = h('span', { class: 'when', title: SL.fmtDateTime(n.updatedAt), text: SL.timeAgo(n.updatedAt) });
    const icons = h('span', { class: 'ic' });
    if (n.pinned) icons.insertAdjacentHTML('beforeend', ico('pin', 13)); if (n.locked) icons.insertAdjacentHTML('beforeend', ico('lock', 13)); if (n.reminder && n.reminder.at) icons.insertAdjacentHTML('beforeend', ico('bell', 13));
    let body;
    if (n.locked) body = h('div', { class: 'd-card-b locked' }, h('div', null, h('div', { html: ico('lock', 26) }), h('div', { text: 'Locked with a password' })));
    else {
      body = h('div', { class: 'd-card-b' });
      const m = /<img[^>]+src="((?:data:image|https:)[^"]+)"/i.exec(n.html || '');
      if (m) body.append(h('img', { src: m[1].replace(/&amp;/g, '&'), alt: '' }));
      body.append(document.createTextNode(noteText(n).slice(0, 260) || (m ? '' : 'Empty note')));
    }
    const foot = h('div', { class: 'd-card-f' });
    if (n.url) foot.append(h('span', { class: 'd-chip', title: n.url, text: SL.host(n.url) }));
    else foot.append(h('span', { class: 'd-chip', text: 'Dashboard only' }));
    (n.tags || []).slice(0, 2).forEach((t) => foot.append(h('span', { class: 'd-chip', text: '# ' + t })));
    foot.append(when);
    el.append(h('div', { class: 'd-card-h' }, h('h3', { text: n.title || 'Untitled' }), icons), body, foot);
    if (state.selecting) {
      const cb = h('input', { class: 'd-check', type: 'checkbox', 'aria-label': 'Select note' }); cb.checked = state.sel.has(n.id);
      cb.addEventListener('click', (e) => e.stopPropagation()); cb.addEventListener('change', () => { toggleSel(n.id, cb.checked); el.classList.toggle('sel', cb.checked); });
      el.append(cb);
    } else {
      el.append(h('div', { class: 'd-card-act' },
        act('pin', n.pinned ? 'Unpin' : 'Pin', () => patch(n, { pinned: !n.pinned })),
        act('copy', 'Make a copy', async () => { await SL.notes.save(SL.notes.duplicate(n)); toast('Copy created'); }),
        act('archive', n.archived ? 'Unarchive' : 'Archive', () => patch(n, { archived: !n.archived }).then(() => toast(n.archived ? 'Archived' : 'Restored'))),
        act('download', 'Export…', () => exportDialog([n])),
        act('trash', 'Delete', () => deleteNotes([n]), 'danger')));
    }
    el.addEventListener('click', () => { if (state.selecting) { const on = !state.sel.has(n.id); toggleSel(n.id, on); el.classList.toggle('sel', on); const cb = el.querySelector('.d-check'); if (cb) cb.checked = on; } else openEditor(n); });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === el) el.click(); });
    return el;
  }
  async function patch(n, p) { Object.assign(n, p); n.rev = (n.rev || 0) + 1; await SL.notes.save(n); }
  function toggleSel(id, on) { if (on) state.sel.add(id); else state.sel.delete(id); renderBulk(); }

  function renderBulk() {
    const b = $('bulk'); b.hidden = !state.selecting; if (!state.selecting) return; b.textContent = '';
    const vis = filtered(); const picked = state.notes.filter((n) => state.sel.has(n.id));
    const btn = (label, fn, cls) => h('button', { class: 'd-btn sm ' + (cls || ''), type: 'button', text: label, onclick: fn, disabled: !picked.length && label !== 'Select all' ? true : null });
    b.append(h('b', { text: picked.length + ' selected' }),
      h('button', { class: 'd-btn sm', type: 'button', text: 'Select all', onclick: () => { vis.forEach((n) => state.sel.add(n.id)); render(); } }),
      btn('Export…', () => exportDialog(picked)),
      btn('Add label…', async () => { const t = await SL.ui.prompt({ title: 'Add label to ' + picked.length + ' notes', label: 'Label', okLabel: 'Add' }); if (t && t.trim()) { for (const n of picked) await patch(n, { tags: Array.from(new Set((n.tags || []).concat(t.trim().slice(0, 40)))) }); toast('Label added'); } }),
      btn(state.view === 'archived' ? 'Unarchive' : 'Archive', async () => { for (const n of picked) await patch(n, { archived: state.view !== 'archived' }); state.sel.clear(); toast('Done'); }),
      btn('Delete', () => deleteNotes(picked), 'danger'));
  }
  async function deleteNotes(list) {
    if (!list.length) return;
    const ok = await SL.ui.confirm('Permanently delete ' + (list.length === 1 ? '“' + (list[0].title || 'Untitled') + '”' : list.length + ' notes') + '? This cannot be undone. (Tip: Archive keeps notes without showing them.)', { title: 'Delete', okLabel: 'Delete', danger: true });
    if (!ok) return;
    for (const n of list) { await SL.notes.remove(n.id); state.sel.delete(n.id); }
    toast(list.length + (list.length === 1 ? ' note deleted' : ' notes deleted'));
  }

  /* ----------------------------------------------------------------- editor */
  function openEditor(n) {
    closeEditor();
    const back = h('div', { class: 'd-editor-back' }); const box = h('div', { class: 'd-editor' }); back.append(box); document.body.append(back);
    const win = new SL.NoteWindow(n, {
      mode: 'embedded', parent: box, autoSave: () => state.settings.autoSave !== false, allTags: async () => allTags(),
      onClose: () => closeEditor(), onDeleted: () => closeEditor()
    });
    back.addEventListener('mousedown', (e) => { if (e.target === back) win.close(); });
    state.editor = { win, back, id: n.id }; win.focus();
    if (!n.title && !n.html) setTimeout(() => win.titleEl.focus(), 50);
  }
  function closeEditor() { if (!state.editor) return; state.editor.win.destroy(); state.editor.back.remove(); state.editor = null; if (location.hash.startsWith('#note=')) history.replaceState(null, '', location.pathname); }
  async function newNote(text) {
    const raw = typeof text === 'string' ? text : '';
    const n = SL.notes.create({ scope: 'none', color: state.settings.defaultColor, title: raw ? raw.split('\n')[0].slice(0, 48) : '', html: raw ? raw.split('\n').map((l) => '<div>' + (SL.esc(l) || '<br>') + '</div>').join('') : '' });
    await SL.notes.save(n); state.notes.push(n); render(); openEditor(n);
  }

  /* ---------------------------------------------------------- export / import */
  function exportDialog(list) {
    if (!list.length) { toast('Nothing to export'); return; }
    let ctl;
    SL.ui.modal({
      title: 'Export ' + list.length + (list.length === 1 ? ' note' : ' notes'), width: 440,
      body: (c) => { ctl = c; return h('div', { class: 'sl-fmts' }, SL.fmt.FORMATS.map((f) => h('button', { class: 'sl-fmt', type: 'button', onclick: () => { const o = SL.fmt.exportBundle(list, f.id); SL.fmt.download(o.name, o.mime, o.data); ctl.close(); toast('Exported ' + o.name); } }, h('b', { text: f.label }), h('small', { text: f.desc })))); },
      buttons: [{ label: 'Close', kind: 'ghost' }]
    });
  }
  async function importFiles(files) {
    let total = 0; const errs = [];
    for (const f of Array.from(files)) {
      try { const ns = await SL.fmt.parseImport(f); for (const n of ns) { await SL.notes.save(n); total++; } } catch (e) { errs.push(f.name + ': ' + (e.message || 'could not read file')); }
    }
    await reload();
    if (errs.length) SL.ui.alert((total ? 'Imported ' + total + ' note(s). ' : '') + 'Some files failed:\n' + errs.join('\n'), 'Import finished');
    else toast('Imported ' + total + (total === 1 ? ' note' : ' notes'));
  }
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function replaceInHtml(html, re, rep) {
    const body = new DOMParser().parseFromString('<body>' + html, 'text/html').body; let count = 0;
    const w = document.createTreeWalker(body, NodeFilter.SHOW_TEXT); const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
    nodes.forEach((t) => { const nv = t.nodeValue.replace(re, () => { count++; return rep; }); if (nv !== t.nodeValue) t.nodeValue = nv; });
    return { html: SL.sanitize(body.innerHTML), count };
  }
  function findReplaceAll() {
    const f = h('input', { class: 'sl-input', placeholder: 'Find', 'data-autofocus': '' }); const r = h('input', { class: 'sl-input', placeholder: 'Replace with' });
    const cs = h('input', { type: 'checkbox' }); const ti = h('input', { type: 'checkbox', checked: true }); const ar = h('input', { type: 'checkbox' }); const out = h('div', { class: 'sl-hint' });
    const run = async (apply) => {
      if (!f.value) { out.textContent = 'Enter text to find.'; return false; }
      const re = new RegExp(escRe(f.value), cs.checked ? 'g' : 'gi'); let hits = 0; let touched = 0;
      for (const n of state.notes) {
        if (n.locked || (n.archived && !ar.checked)) continue;
        const res = replaceInHtml(n.html, re, r.value); let tc = 0; let title = n.title;
        if (ti.checked) title = (n.title || '').replace(re, () => { tc++; return r.value; });
        if (res.count + tc === 0) continue; hits += res.count + tc; touched++;
        if (apply) { n.versions = (n.versions || []).concat({ t: Date.now(), title: n.title, html: n.html }).slice(-30); n.html = res.html; n.title = title; n.updatedAt = Date.now(); n.rev = (n.rev || 0) + 1; await SL.notes.save(n); }
      }
      out.textContent = apply ? 'Replaced ' + hits + ' match(es) in ' + touched + ' note(s).' : hits + ' match(es) in ' + touched + ' note(s). Locked notes are skipped.';
      return false;
    };
    SL.ui.modal({
      title: 'Find & replace in all notes', width: 460,
      body: h('div', null, h('label', { class: 'sl-label', text: 'Find' }), f, h('label', { class: 'sl-label', text: 'Replace with' }), r,
        h('div', { style: { display: 'grid', gap: '4px', marginTop: '10px' } }, h('label', { class: 'sl-inline' }, cs, ' Match case'), h('label', { class: 'sl-inline' }, ti, ' Also replace in titles'), h('label', { class: 'sl-inline' }, ar, ' Include archived notes')), out),
      buttons: [{ label: 'Close', kind: 'ghost' }, { label: 'Preview', kind: 'ghost', onClick: () => run(false) }, { label: 'Replace all', kind: 'primary', onClick: async () => { const ok = await SL.ui.confirm('Replace in all matching notes? Earlier versions are kept in each note’s history.', { okLabel: 'Replace all' }); if (ok) await run(true); return false; } }]
    });
  }

  /* -------------------------------------------------------------- data view */
  function renderData(c) {
    c.append(h('div', { class: 'd-h' }, h('h2', { text: 'Import & export' })));
    let scope = 'active';
    const exp = h('div', { class: 'd-panel' }, h('h3', { text: 'Export notes' }), h('p', { text: 'Download your notes in the format you need. Locked notes are exported encrypted in .json and as a placeholder elsewhere.' }),
      h('div', { class: 'd-radio' }, [['active', 'All notes'], ['all', 'Including archived'], ['sel', 'Selected only']].map(([v, l]) => h('label', null, h('input', { type: 'radio', name: 'scope', value: v, checked: v === 'active', onchange: () => { scope = v; } }), l))),
      h('div', { class: 'd-fmt-grid' }, SL.fmt.FORMATS.map((f) => h('button', {
        class: 'd-fmt', type: 'button', onclick: () => {
          const list = state.notes.filter((n) => scope === 'all' || (scope === 'active' && !n.archived) || (scope === 'sel' && state.sel.has(n.id)));
          if (!list.length) { toast(scope === 'sel' ? 'Select notes first (use “Select” on a notes page)' : 'Nothing to export'); return; }
          const o = SL.fmt.exportBundle(list, f.id); SL.fmt.download(o.name, o.mime, o.data); toast('Exported ' + list.length + ' note(s)');
        }
      }, h('b', { text: f.label }), h('small', { text: f.desc })))));
    const fileIn = h('input', { type: 'file', multiple: true, accept: '.json,.md,.markdown,.doc,.html,.htm,.sheet,.csv,.notepad,.txt', hidden: true, onchange: (e) => { importFiles(e.target.files); e.target.value = ''; } });
    const drop = h('label', { class: 'd-drop' }, h('span', { html: ico('upload', 28) }), h('b', { text: 'Drop files here or click to browse' }), h('small', { text: '.json  .md  .doc  .sheet  .notepad  .csv  .txt' }), fileIn);
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => importFiles(e.dataTransfer.files));
    c.append(exp, h('div', { class: 'd-panel' }, h('h3', { text: 'Import notes' }), h('p', { text: 'Bulk-import notes from a Skylab backup or from other apps. Imported text files become dashboard notes you can bind to any site.' }), drop),
      h('div', { class: 'd-panel' }, h('h3', { text: 'Find & replace across notes' }), h('p', { text: 'Fix a name, URL or phrase in every note at once.' }), h('button', { class: 'd-btn', type: 'button', text: 'Open find & replace', onclick: findReplaceAll })),
      h('div', { class: 'd-panel' }, h('h3', { text: 'Danger zone' }), h('p', { text: 'These actions cannot be undone — export a backup first.' }),
        h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
          h('button', { class: 'd-btn', type: 'button', text: 'Empty archive', onclick: async () => { const l = state.notes.filter((n) => n.archived); if (!l.length) { toast('Archive is already empty'); return; } await deleteNotes(l); } }),
          h('button', { class: 'd-btn danger', type: 'button', text: 'Delete all notes', onclick: async () => { if (!state.notes.length) { toast('No notes to delete'); return; } const t = await SL.ui.prompt({ title: 'Delete ALL notes', label: 'Type DELETE to confirm removing ' + state.notes.length + ' notes', okLabel: 'Delete everything' }); if (t === 'DELETE') { for (const n of state.notes) await SL.notes.remove(n.id); toast('All notes deleted'); } else if (t != null) toast('Confirmation did not match'); } }))));
  }

  /* ------------------------------------------------------------ settings view */
  function sw(key, label, desc) {
    const cb = h('input', { type: 'checkbox', 'aria-label': label }); cb.checked = !!state.settings[key];
    cb.addEventListener('change', async () => { state.settings = await SL.settings.set({ [key]: cb.checked }); toast(label + (cb.checked ? ': on' : ': off')); });
    return h('div', { class: 'd-row' }, h('div', { class: 'l' }, h('b', { text: label }), h('small', { text: desc })), h('label', { class: 'd-switch' }, cb, h('i')));
  }
  async function renderSettings(c) {
    c.append(h('div', { class: 'd-h' }, h('h2', { text: 'Settings' })));
    const theme = h('select', { class: 'd-select', onchange: async (e) => { state.settings = await SL.settings.set({ theme: e.target.value }); applyTheme(); } }, [['auto', 'Match system'], ['light', 'Light'], ['dark', 'Dark']].map(([v, l]) => h('option', { value: v, text: l }))); theme.value = state.settings.theme;
    const scope = h('select', { class: 'd-select', onchange: async (e) => { state.settings = await SL.settings.set({ defaultScope: e.target.value }); toast('Default binding saved'); } }, [['url', 'This page only'], ['domain', 'Whole website'], ['global', 'All websites']].map(([v, l]) => h('option', { value: v, text: l }))); scope.value = state.settings.defaultScope;
    const sws = h('div', { class: 'd-swatches' }, SL.COLORS.map((col) => h('button', { class: 'sl-sw' + (state.settings.defaultColor.toLowerCase() === col.hex.toLowerCase() ? ' on' : ''), type: 'button', title: col.name, style: { background: col.hex }, onclick: async () => { state.settings = await SL.settings.set({ defaultColor: col.hex }); renderSettingsRefresh(); } })));
    sws.append(h('label', { class: 'sl-sw wheel', title: 'Color wheel' }, h('input', { type: 'color', value: state.settings.defaultColor, onchange: async (e) => { state.settings = await SL.settings.set({ defaultColor: e.target.value }); renderSettingsRefresh(); } })));
    c.append(h('div', { class: 'd-panel' }, h('h3', { text: 'On websites' }), h('p', { text: 'How notes behave on the pages you visit.' }),
      sw('showIcon', 'Show icon in website', 'Floating Skylab button on every page. Turn off for “Don’t show icon” — notes on a page still open from the toolbar popup.'),
      sw('autoSave', 'Auto-save while typing', 'Notes are saved locally a moment after you stop typing. When off, press Ctrl+S or the Save button.'),
      sw('notifications', 'Reminder notifications', 'Show system notifications in addition to the in-page pop-up.'),
      h('div', { class: 'd-row' }, h('div', { class: 'l' }, h('b', { text: 'Default note color' }), h('small', { text: 'Used for new notes.' })), sws),
      h('div', { class: 'd-row' }, h('div', { class: 'l' }, h('b', { text: 'Default binding' }), h('small', { text: 'Where a new website note appears.' })), scope)),
      h('div', { class: 'd-panel' }, h('h3', { text: 'Appearance' }), h('div', { class: 'd-row' }, h('div', { class: 'l' }, h('b', { text: 'Dashboard theme' })), theme)));

    /* local folder */
    const fbox = h('div', { class: 'd-panel' }); c.append(fbox);
    async function paintFolder() {
      fbox.textContent = ''; const st = await SL.folder.status();
      fbox.append(h('h3', { text: 'Local folder (optional)' }), h('p', { text: 'Mirror every unlocked note as a Markdown file into a folder you choose. Notes always stay stored in the extension too.' }));
      if (st.state === 'unsupported') { fbox.append(h('p', { text: 'Your browser does not support choosing a folder.' })); return; }
      const row = h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' } });
      if (st.state === 'none') row.append(h('button', { class: 'd-btn primary', type: 'button', html: ico('folder') + ' Choose folder…', onclick: async () => { try { await SL.folder.pick(); const r = await SL.folder.syncAll({ all: true, request: true }); state.settings = await SL.settings.get(); toast('Folder connected · ' + r.written + ' files written'); } catch (e) { if (e.name !== 'AbortError') toast(e.message || 'Could not use that folder'); } paintFolder(); } }));
      else {
        row.append(h('span', { class: 'd-status ' + (st.state === 'ready' ? 'ok' : 'warn'), text: (st.state === 'ready' ? 'Connected: ' : 'Needs permission: ') + st.name }));
        if (st.state !== 'ready') row.append(h('button', { class: 'd-btn', type: 'button', text: 'Reconnect', onclick: async () => { try { await SL.folder.syncAll({ all: true, request: true }); toast('Reconnected'); } catch (e) { toast(e.message); } paintFolder(); } }));
        row.append(h('button', { class: 'd-btn', type: 'button', text: 'Sync now', onclick: async () => { try { const r = await SL.folder.syncAll({ all: true, request: true }); toast('Synced ' + r.written + ' notes' + (r.skipped ? ' · ' + r.skipped + ' locked skipped' : '')); } catch (e) { toast(e.message); } paintFolder(); } }),
          h('button', { class: 'd-btn', type: 'button', text: 'Change folder…', onclick: async () => { try { await SL.folder.pick(); await SL.folder.syncAll({ all: true, request: true }); toast('Folder changed'); } catch (e) { if (e.name !== 'AbortError') toast(e.message); } paintFolder(); } }),
          h('button', { class: 'd-btn', type: 'button', text: 'Disconnect', onclick: async () => { await SL.folder.forget(); state.settings = await SL.settings.get(); toast('Folder disconnected'); paintFolder(); } }));
        fbox.append(row, h('p', { class: 'sl-hint', text: 'Files update while this dashboard is open and whenever you open the toolbar popup. Browsers may ask you to re-confirm folder access after a restart.' }));
        return;
      }
      fbox.append(row);
    }
    paintFolder();

    const isEdge = /Edg\//.test(navigator.userAgent);
    c.append(h('div', { class: 'd-panel' }, h('h3', { text: 'Keyboard shortcuts' }),
      h('div', { class: 'd-kbd' }, h('kbd', { text: 'Alt+Shift+N' }), h('span', { text: 'New note on the current page' }), h('kbd', { text: 'Alt+Shift+H' }), h('span', { text: 'Show / hide notes on the current page' }),
        h('kbd', { text: 'Ctrl+S' }), h('span', { text: 'Save note now (and snapshot a version)' }), h('kbd', { text: 'Ctrl+F' }), h('span', { text: 'Find & replace inside a note' }), h('kbd', { text: 'Ctrl+B / I / U' }), h('span', { text: 'Bold / italic / underline' }),
        h('kbd', { text: '/' }), h('span', { text: 'Search (this dashboard)' }), h('kbd', { text: 'N' }), h('span', { text: 'New note (this dashboard)' })),
      h('button', { class: 'd-btn', type: 'button', text: 'Customize browser shortcuts', onclick: () => { try { chrome.tabs.create({ url: (isEdge ? 'edge' : 'chrome') + '://extensions/shortcuts' }); } catch (e) { toast('Open ' + (isEdge ? 'edge' : 'chrome') + '://extensions/shortcuts'); } } })));
    const bytes = await SL.store.bytes();
    c.append(h('div', { class: 'd-panel' }, h('h3', { text: 'About & privacy' }),
      h('p', { text: 'Skylab Sticky Note v' + SL.VERSION + ' keeps everything on this device — no accounts, no servers, no tracking. Locked notes use AES-256-GCM with a key derived from your password (PBKDF2, 200 000 rounds). Using ' + (bytes / 1024 < 1024 ? Math.round(bytes / 1024) + ' KB' : (bytes / 1048576).toFixed(1) + ' MB') + ' for ' + state.notes.length + ' notes.' })));
  }
  function renderSettingsRefresh() { if (state.view === 'settings') render(); }

  /* ------------------------------------------------------------------- init */
  await reload();
  $('btnMenu').innerHTML = ico('menu', 18); $('searchIc').innerHTML = ico('search', 16);
  $('layoutSeg').querySelector('[data-l="grid"]').innerHTML = ico('grid', 16); $('layoutSeg').querySelector('[data-l="list"]').innerHTML = ico('list', 16);
  $('verTxt').textContent = 'v' + SL.VERSION;
  $('btnNew').onclick = () => newNote();
  $('btnMenu').onclick = () => { $('side').classList.add('open'); $('scrim').classList.add('open'); };
  $('scrim').onclick = () => { $('side').classList.remove('open'); $('scrim').classList.remove('open'); };
  $('q').addEventListener('input', (e) => { state.q = e.target.value.trim(); if (state.view === 'data' || state.view === 'settings') state.view = 'all'; render(); });
  $('sort').onchange = async (e) => { state.settings = await SL.settings.set({ sort: e.target.value }); render(); };
  $('layoutSeg').onclick = async (e) => { const b = e.target.closest('button'); if (!b) return; state.settings = await SL.settings.set({ layout: b.dataset.l }); render(); };
  $('btnSelect').onclick = () => { state.selecting = !state.selecting; if (!state.selecting) state.sel.clear(); render(); };
  $('btnTheme').onclick = async () => { const dark = document.documentElement.dataset.theme === 'dark'; state.settings = await SL.settings.set({ theme: dark ? 'light' : 'dark' }); applyTheme(); };
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

  document.addEventListener('keydown', (e) => {
    const typing = /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable;
    if (e.key === 'Escape') { if (layer.childElementCount) return; if (state.editor) state.editor.win.close(); else if (state.selecting) $('btnSelect').click(); return; }
    if (typing || state.editor || layer.childElementCount || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '/') { e.preventDefault(); $('q').focus(); } else if (e.key.toLowerCase() === 'n') { e.preventDefault(); newNote(); }
  });

  let reloadTimer = null; let folderTimers = {};
  SL.store.onChanged((ch) => {
    Object.keys(ch).forEach((k) => {
      if (!k.startsWith(SL.notes.P)) return; const id = k.slice(SL.notes.P.length); const nv = ch[k].newValue;
      if (state.editor && state.editor.id === id) { if (nv) state.editor.win.applyRemote(nv); else closeEditor(); }
      if (state.settings.folderEnabled && SL.folder.supported) { clearTimeout(folderTimers[id]); folderTimers[id] = setTimeout(() => { (nv ? SL.folder.writeOne(nv) : SL.folder.removeOne(id)).catch(() => {}); }, 800); }
    });
    clearTimeout(reloadTimer); reloadTimer = setTimeout(async () => { if (state.editor && document.activeElement && state.editor.back.contains(document.activeElement)) { state.notes = await SL.notes.all(); state.settings = await SL.settings.get(); renderNav(); return; } const open = document.activeElement && document.activeElement.closest && document.activeElement.closest('.d-panel'); if (open && state.view === 'settings') { state.notes = await SL.notes.all(); return; } reload(); }, 250);
  });
  SL.ui.openNoteHandler = async (id) => { const n = await SL.notes.get(id); if (n) openEditor(n); };
  window.addEventListener('beforeunload', () => { if (state.editor) state.editor.win.flush(); });

  async function route() {
    const hash = location.hash || '';
    if (hash === '#settings') go('settings');
    else if (hash.startsWith('#note=')) { const n = await SL.notes.get(hash.slice(6)); if (n) openEditor(n); }
    else if (hash === '#new') { history.replaceState(null, '', location.pathname); newNote(); }
    else if (hash.startsWith('#new=')) { const t = decodeURIComponent(hash.slice(5)); history.replaceState(null, '', location.pathname); newNote(t); }
    else if (hash === '#welcome' && !state.settings.welcomed) {
      history.replaceState(null, '', location.pathname); await SL.settings.set({ welcomed: true });
      SL.ui.modal({
        title: 'Welcome to Skylab Sticky Note', width: 460,
        body: h('div', { class: 'd-welcome' }, h('img', { src: 'icons/icon128.png', width: 72, height: 72, alt: '' }),
          h('ul', null, h('li', { text: 'Click the floating icon on any website — or press Alt+Shift+N — to pin a note to that page.' }), h('li', { text: 'Select text, right-click and choose “Add selection to a Skylab sticky note”.' }), h('li', { text: 'Everything is stored on this device and works offline.' })),
          h('p', { class: 'sl-p', text: 'Optional: choose a local folder to also keep a Markdown copy of every note.' })),
        buttons: [{ label: 'Skip', kind: 'ghost', value: false }, ...(SL.folder.supported ? [{ label: 'Choose folder…', kind: 'primary', value: true }] : [{ label: 'Get started', kind: 'primary', value: false }])]
      }).then(async (v) => { if (v) { try { await SL.folder.pick(); const r = await SL.folder.syncAll({ all: true, request: true }); toast('Folder connected · ' + r.written + ' files'); } catch (e) { if (e.name !== 'AbortError') toast(e.message || 'Could not use that folder'); } } });
    }
  }
  window.addEventListener('hashchange', route);
  route();
})();
